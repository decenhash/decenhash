import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.imageio.ImageIO;

public class ArtGenerator {
    
    public static void main(String[] args) {
        // Directory containing images
        String directoryPath = "img_shuffle";
        
        // Create File object for the directory
        File directory = new File(directoryPath);
        
        // Check if directory exists
        if (!directory.exists() || !directory.isDirectory()) {
            System.out.println("Error: Directory '" + directoryPath + "' not found or is not a directory");
            waitForEnterKey();
            return;
        }
        
        // Get all files in the directory
        File[] files = directory.listFiles();
        
        if (files == null || files.length == 0) {
            System.out.println("No files found in '" + directoryPath + "' directory");
            waitForEnterKey();
            return;
        }
        
        int processedCount = 0;
        int errorCount = 0;
        
        // Process each file in the directory
        for (File file : files) {
            if (isImageFile(file.getName())) {
                try {
                    System.out.println("\nProcessing image: " + file.getName());
                    
                    // Read the image
                    BufferedImage originalImage = ImageIO.read(file);
                    
                    if (originalImage == null) {
                        System.out.println("Could not read image: " + file.getName());
                        errorCount++;
                        continue;
                    }
                    
                    String format = getImageFormat(file.getName());
                    String baseName = getBaseFileName(file.getName());
                    
                    // Process vertical shuffling
                    BufferedImage verticalShuffledImage = shuffleVerticalLines(originalImage);
                    File verticalOutputFile = new File(directory, baseName + "_vertical_shuffled." + format);
                    ImageIO.write(verticalShuffledImage, format, verticalOutputFile);
                    System.out.println("Created vertically shuffled image: " + verticalOutputFile.getName());
                    
                    // Process horizontal shuffling
                    BufferedImage horizontalShuffledImage = shuffleHorizontalLines(originalImage);
                    File horizontalOutputFile = new File(directory, baseName + "_horizontal_shuffled." + format);
                    ImageIO.write(horizontalShuffledImage, format, horizontalOutputFile);
                    System.out.println("Created horizontally shuffled image: " + horizontalOutputFile.getName());
                    
                    processedCount++;
                    
                } catch (IOException e) {
                    System.out.println("Error processing image " + file.getName() + ": " + e.getMessage());
                    errorCount++;
                }
            }
        }
        
        // Print summary
        System.out.println("\n--- Summary ---");
        System.out.println("Images processed successfully: " + processedCount);
        System.out.println("Images with errors: " + errorCount);
        System.out.println("Total files checked: " + files.length);
        System.out.println("Total output images created: " + (processedCount * 2)); // Two images per successful process
        
        // Wait for user to press Enter
        waitForEnterKey();
    }
    
    /**
     * Shuffles the vertical lines of an image (1 pixel wide columns)
     * 
     * @param image The original image
     * @return A new image with shuffled vertical lines
     */
    private static BufferedImage shuffleVerticalLines(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        
        // Create a new image with the same dimensions
        BufferedImage shuffledImage = new BufferedImage(width, height, image.getType());
        
        // Create a list of indices for the vertical lines
        List<Integer> indices = new ArrayList<>(width);
        for (int i = 0; i < width; i++) {
            indices.add(i);
        }
        
        // Shuffle the indices
        Collections.shuffle(indices, new Random());
        
        // Copy each vertical line from the original image to its new position
        for (int x = 0; x < width; x++) {
            int newX = indices.get(x);
            
            // Copy the entire vertical line
            for (int y = 0; y < height; y++) {
                int rgb = image.getRGB(x, y);
                shuffledImage.setRGB(newX, y, rgb);
            }
        }
        
        return shuffledImage;
    }
    
    /**
     * Shuffles the horizontal lines of an image (1 pixel high rows)
     * 
     * @param image The original image
     * @return A new image with shuffled horizontal lines
     */
    private static BufferedImage shuffleHorizontalLines(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        
        // Create a new image with the same dimensions
        BufferedImage shuffledImage = new BufferedImage(width, height, image.getType());
        
        // Create a list of indices for the horizontal lines
        List<Integer> indices = new ArrayList<>(height);
        for (int i = 0; i < height; i++) {
            indices.add(i);
        }
        
        // Shuffle the indices
        Collections.shuffle(indices, new Random());
        
        // Copy each horizontal line from the original image to its new position
        for (int y = 0; y < height; y++) {
            int newY = indices.get(y);
            
            // Copy the entire horizontal line
            for (int x = 0; x < width; x++) {
                int rgb = image.getRGB(x, y);
                shuffledImage.setRGB(x, newY, rgb);
            }
        }
        
        return shuffledImage;
    }
    
    /**
     * Checks if a file is an image based on its extension
     * 
     * @param fileName Name of the file
     * @return true if the file is an image, false otherwise
     */
    private static boolean isImageFile(String fileName) {
        fileName = fileName.toLowerCase();
        return fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") || 
               fileName.endsWith(".png") || fileName.endsWith(".bmp") || 
               fileName.endsWith(".gif");
    }
    
    /**
     * Gets the base file name without extension
     * 
     * @param fileName The original file name
     * @return The base file name
     */
    private static String getBaseFileName(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return fileName;
        } else {
            return fileName.substring(0, lastDotIndex);
        }
    }
    
    /**
     * Gets the image format from the file name
     * 
     * @param fileName The file name
     * @return The image format (jpg, png, etc.)
     */
    private static String getImageFormat(String fileName) {
        String lowerCase = fileName.toLowerCase();
        int dotIndex = lowerCase.lastIndexOf('.');
        if (dotIndex != -1 && dotIndex < lowerCase.length() - 1) {
            String extension = lowerCase.substring(dotIndex + 1);
            if (extension.equals("jpg") || extension.equals("jpeg")) {
                return "jpg";
            }
            return extension;
        }
        return "png"; // Default format
    }
    
    /**
     * Waits for the user to press Enter before continuing
     */
    private static void waitForEnterKey() {
        System.out.println("\nPress Enter key to exit...");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
        scanner.close();
    }
}