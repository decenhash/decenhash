import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class GalleryIndexer {
    // List of common image file extensions
    private static final List<String> IMAGE_EXTENSIONS = Arrays.asList(
            ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".tif"
    );
    
    static class ImageInfo {
        File file;
        int width;
        int height;
        boolean isPortrait; // true if height > width
        
        public ImageInfo(File file, int width, int height) {
            this.file = file;
            this.width = width;
            this.height = height;
            this.isPortrait = height > width;
        }
    }
    
    public static void main(String[] args) {
        // Directory to scan
        File galleryDir = new File("gallery");
        
        // Check if directory exists
        if (!galleryDir.exists() || !galleryDir.isDirectory()) {
            System.err.println("Error: The 'gallery' directory does not exist.");
            System.exit(1);
        }
        
        try {
            // List all files in the gallery directory
            File[] files = galleryDir.listFiles();
            List<ImageInfo> imageInfoList = new ArrayList<>();
            
            if (files != null) {
                // Process each file
                for (File file : files) {
                    if (file.isFile() && isImageFile(file.getName())) {
                        try {
                            BufferedImage img = ImageIO.read(file);
                            if (img != null) {
                                imageInfoList.add(new ImageInfo(file, img.getWidth(), img.getHeight()));
                            }
                        } catch (IOException e) {
                            System.err.println("Error reading image " + file.getName() + ": " + e.getMessage());
                        }
                    }
                }
                
                // Sort images: first by orientation (portrait first), then by size within each orientation
                imageInfoList.sort(new Comparator<ImageInfo>() {
                    @Override
                    public int compare(ImageInfo a, ImageInfo b) {
                        // First compare by orientation
                        if (a.isPortrait != b.isPortrait) {
                            return a.isPortrait ? -1 : 1;
                        }
                        // If both are portrait, sort by height (larger first)
                        if (a.isPortrait) {
                            return Integer.compare(b.height, a.height);
                        }
                        // If both are landscape, sort by width (larger first)
                        return Integer.compare(b.width, a.width);
                    }
                });
                
                // Create or overwrite index.html
                FileWriter writer = new FileWriter("index.html");
                
                // Write HTML header
                writer.write("<!DOCTYPE html>\n");
                writer.write("<html>\n");
                writer.write("<head>\n");
                writer.write("    <title>Image Gallery</title>\n");
                writer.write("    <meta charset=\"UTF-8\">\n");
                writer.write("    <style>\n");
                writer.write("        body { font-family: Arial, sans-serif; margin: 20px; }\n");
                writer.write("        h1 { color: #333; }\n");
                writer.write("        .gallery { display: flex; flex-wrap: wrap; }\n");
                writer.write("        .gallery-item { margin: 10px; text-align: center; }\n");
                writer.write("        .portrait { height: 300px; }\n");
                writer.write("        .landscape { width: 300px; }\n");
                writer.write("    </style>\n");
                writer.write("</head>\n");
                writer.write("<body>\n");
                writer.write("    <h1>Image Gallery</h1>\n");
                writer.write("    <div class=\"gallery\">\n");
                
                // Add images to HTML
                for (ImageInfo info : imageInfoList) {
                    String fileName = info.file.getName();
                    String cssClass = info.isPortrait ? "portrait" : "landscape";
                    
                    writer.write("        <div class=\"gallery-item\">\n");
                    writer.write("            <a href='gallery/" + fileName + "'>\n");
                    writer.write("                <img src='gallery/" + fileName + "' class='" + cssClass + "'>\n");
                    writer.write("            </a>\n");
                    writer.write("        </div>\n");
                }
                
                if (imageInfoList.isEmpty()) {
                    writer.write("        <p>No images found in the gallery directory.</p>\n");
                }
                
                // Write HTML footer
                writer.write("    </div>\n");
                writer.write("</body>\n");
                writer.write("</html>");
                
                writer.close();
                System.out.println("Successfully generated index.html");
            }
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Helper method to check if a file is an image based on its extension
    private static boolean isImageFile(String fileName) {
        String lowerCaseName = fileName.toLowerCase();
        return IMAGE_EXTENSIONS.stream().anyMatch(ext -> lowerCaseName.endsWith(ext));
    }
}