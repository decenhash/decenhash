import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class ImageOrganizer {
    public static void main(String[] args) {
        // Define the source and destination directories
        String galleryFolder = "gallery";
        String heightFolder = "H";
        String widthFolder = "W";
        String squareFolder = "S";
        
        // Ensure destination directories exist
        createDirectoryIfNotExists(heightFolder);
        createDirectoryIfNotExists(widthFolder);
        createDirectoryIfNotExists(squareFolder);
        
        // Get all files from gallery
        File gallery = new File(galleryFolder);
        File[] files = gallery.listFiles((dir, name) -> {
            String lowercaseName = name.toLowerCase();
            return lowercaseName.endsWith(".jpg") || 
                   lowercaseName.endsWith(".jpeg") || 
                   lowercaseName.endsWith(".png") || 
                   lowercaseName.endsWith(".gif") || 
                   lowercaseName.endsWith(".bmp");
        });
        
        if (files == null || files.length == 0) {
            System.out.println("No image files found in the gallery folder.");
            return;
        }
        
        // Sort files by name to process them in order
        Arrays.sort(files);
        
        // Counters for each destination folder
        int heightCounter = 1;
        int widthCounter = 1;
        int squareCounter = 1;
        
        for (File file : files) {
            try {
                // Read the image to get its dimensions
                BufferedImage image = ImageIO.read(file);
                
                if (image == null) {
                    System.out.println("Could not read image: " + file.getName());
                    continue;
                }
                
                int width = image.getWidth();
                int height = image.getHeight();
                
                String destinationFolder;
                int counter;
                
                // Determine the appropriate folder based on dimensions
                if (height > width) {
                    destinationFolder = heightFolder;
                    counter = heightCounter++;
                } else if (width > height) {
                    destinationFolder = widthFolder;
                    counter = widthCounter++;
                } else {
                    destinationFolder = squareFolder;
                    counter = squareCounter++;
                }
                
                // Get the file extension
                String fileName = file.getName();
                String extension = fileName.substring(fileName.lastIndexOf('.'));
                
                // Create the new file name
                String newFileName = counter + extension;
                
                // Move the file
                Path source = file.toPath();
                Path destination = Paths.get(destinationFolder, newFileName);
                Files.move(source, destination, StandardCopyOption.REPLACE_EXISTING);
                
                System.out.println("Moved " + file.getName() + " to " + destinationFolder + "/" + newFileName);
                
            } catch (IOException e) {
                System.out.println("Error processing file " + file.getName() + ": " + e.getMessage());
            }
        }
        
        System.out.println("\nProcessing complete!");
        System.out.println("Files moved to H folder: " + (heightCounter - 1));
        System.out.println("Files moved to W folder: " + (widthCounter - 1));
        System.out.println("Files moved to S folder: " + (squareCounter - 1));
    }
    
    private static void createDirectoryIfNotExists(String directoryName) {
        File directory = new File(directoryName);
        if (!directory.exists()) {
            if (directory.mkdir()) {
                System.out.println("Created directory: " + directoryName);
            } else {
                System.out.println("Failed to create directory: " + directoryName);
            }
        }
    }
}