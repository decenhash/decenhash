<?php
// Define the directory to scan
$directory = 'files';

// Check if directory exists
if (!is_dir($directory)) {
    die("Error: Directory '$directory' does not exist.");
}

// Configuration
$maxEntriesPerFile = 20;
$maxFileSizeKB = 20;

// Define file type categories
$fileCategories = [
    'image' => ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'],
    'music' => ['mp3', 'wav', 'ogg', 'flac', 'aac'],
    'video' => ['mp4', 'mov', 'avi', 'mkv', 'flv', 'webm'],
    'pdf' => ['pdf'],
    'zip' => ['zip', 'rar', '7z', 'tar', 'gz'],
    'other' => [] // Default category
];

// Initialize an array to hold files grouped by category
$filesByCategory = [];

// Scan the directory
$files = scandir($directory);

foreach ($files as $file) {
    // Skip current and parent directory entries
    if ($file === '.' || $file === '..') {
        continue;
    }
    
    $filePath = $directory . '/' . $file;
    
    // Skip directories (only process files)
    if (is_dir($filePath)) {
        continue;
    }
    
    // Get file information
    $pathInfo = pathinfo($filePath);
    $extension = isset($pathInfo['extension']) ? strtolower($pathInfo['extension']) : 'none';
    
    // Determine the file category
    $category = 'other';
    foreach ($fileCategories as $cat => $extensions) {
        if (in_array($extension, $extensions)) {
            $category = $cat;
            break;
        }
    }
    
    // If no extension, use 'other' category
    if ($extension === 'none') {
        $category = 'other';
    }
    
    // Generate a simple hash of the file
    $fileHash = md5_file($filePath);
    
    // Create file metadata
    $fileData = [
        'filename' => $file,
        'user' => get_current_user(), // Current system user
        'date' => date('Y-m-d', filemtime($filePath)), // Last modified date
        'hash' => $fileHash,
        'extension' => $extension,
        'link' => "files/$file",
        'url' => "",
        'description' => "" // Empty description by default
    ];
    
    // Add to the appropriate category group
    if (!isset($filesByCategory[$category])) {
        $filesByCategory[$category] = [];
    }
    $filesByCategory[$category][] = $fileData;
}

// Function to save paginated JSON files
function savePaginatedJson($category, $files, $maxEntries, $maxSizeKB) {
    $chunks = [];
    $currentChunk = [];
    $currentSize = 0;
    
    foreach ($files as $file) {
        $fileSize = strlen(json_encode($file));
        
        // Check if adding this file would exceed limits
        if (count($currentChunk) >= $maxEntries || 
            ($currentSize + $fileSize) > ($maxSizeKB * 1024)) {
            // Save current chunk and start new one
            $chunks[] = $currentChunk;
            $currentChunk = [];
            $currentSize = 0;
        }
        
        $currentChunk[] = $file;
        $currentSize += $fileSize;
    }
    
    // Add the last chunk if not empty
    if (!empty($currentChunk)) {
        $chunks[] = $currentChunk;
    }
    
    // Save each chunk to separate file
    foreach ($chunks as $index => $chunk) {
        $fileNumber = $index + 1;
        $jsonFileName = ($fileNumber === 1) ? "$category.json" : "{$category}_{$fileNumber}.json";
        
        $jsonData = [
            'files' => $chunk,
            'metadata' => [
                'total_files' => count($files),
                'current_chunk' => $fileNumber,
                'total_chunks' => count($chunks),
                'chunk_size' => count($chunk),
                'chunk_size_kb' => round(strlen(json_encode($jsonData)) / 1024, 2)
            ]
        ];
        
        file_put_contents($jsonFileName, json_encode($jsonData, JSON_PRETTY_PRINT));
        echo "Created JSON file: $jsonFileName with " . count($chunk) . " entries (" . 
             round(strlen(json_encode($jsonData)) / 1024, 2) . " KB).\n";
    }
}

// Process each category
foreach ($filesByCategory as $category => $files) {
    savePaginatedJson($category, $files, $maxEntriesPerFile, $maxFileSizeKB);
}

echo "Processing complete.\n";
?>