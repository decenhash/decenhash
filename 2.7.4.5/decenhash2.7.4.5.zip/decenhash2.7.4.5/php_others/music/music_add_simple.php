<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Directory configurations
    $musicDir = 'music/';
    $jsonFile = 'data_json/data.json';
    
    // Ensure directories exist
    if (!file_exists($musicDir)) {
        mkdir($musicDir, 0777, true);
    }
    if (!file_exists('data_json')) {
        mkdir('data_json', 0777, true);
    }
    
    // Process uploaded files
    $artist = str_replace(' ', '_', $_POST['artist']);
    $title = str_replace(' ', '_', $_POST['title']);
    $filename = $artist . '-' . $title;
    
    // Handle MP3 upload
    $mp3Path = '';
    if (isset($_FILES['mp3']) && $_FILES['mp3']['error'] === UPLOAD_ERR_OK) {
        $mp3Ext = pathinfo($_FILES['mp3']['name'], PATHINFO_EXTENSION);
        $mp3Filename = $filename . '.' . $mp3Ext;
        $mp3Path = $musicDir . $mp3Filename;
        move_uploaded_file($_FILES['mp3']['tmp_name'], $mp3Path);
    }
    
    // Handle cover art upload
    $thumbPath = '';
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $coverExt = pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION);
        $coverFilename = $artist . '.' . $coverExt;
        $thumbPath = $musicDir . $coverFilename;
        move_uploaded_file($_FILES['cover']['tmp_name'], $thumbPath);
    }
    
    // Load existing JSON data or initialize if empty
    $jsonData = [];
    if (file_exists($jsonFile)) {
        $jsonData = json_decode(file_get_contents($jsonFile), true);
    }
    
    // Create new entry
    $newEntry = [
        'id' => count($jsonData),
        'filename' => basename($mp3Path),
        'filePath' => $mp3Path,
        'title' => $title,
        'artist' => str_replace('_', ' ', $artist),
        'thumbPath' => $thumbPath
    ];
    
    // Add to JSON array
    $jsonData[] = $newEntry;
    
    // Save back to JSON file
    file_put_contents($jsonFile, json_encode($jsonData, JSON_PRETTY_PRINT));
    
    // Success message
    $success = "Upload successful! Entry added to data.json.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music Uploader</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            color: #333;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        input[type="file"] {
            padding: 5px;
        }
        
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        
        button:hover {
            background-color: #2980b9;
        }
        
        .success {
            background-color: #2ecc71;
            color: white;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .file-info {
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Music Uploader</h1>
        
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="artist">Artist Name</label>
                <input type="text" id="artist" name="artist" required>
                <div class="file-info">Spaces will be replaced with underscores (_)</div>
            </div>
            
            <div class="form-group">
                <label for="title">Track Title</label>
                <input type="text" id="title" name="title" required>
                <div class="file-info">Spaces will be replaced with underscores (_)</div>
            </div>
            
            <div class="form-group">
                <label for="mp3">MP3 File</label>
                <input type="file" id="mp3" name="mp3" accept=".mp3" required>
                <div class="file-info">File will be renamed to: artist-tracktitle.mp3</div>
            </div>
            
            <div class="form-group">
                <label for="cover">Cover Art</label>
                <input type="file" id="cover" name="cover" accept="image/*">
                <div class="file-info">File will be renamed to: artist.jpg/png</div>
            </div>
            
            <button type="submit">Upload Music</button>
        </form>
    </div>
</body>
</html>