import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FileScanner {
    
    public static void main(String[] args) {
        try {
            // Directory to scan
            String directoryPath = "files";
            File directory = new File(directoryPath);
            
            // Check if directory exists
            if (!directory.exists() || !directory.isDirectory()) {
                System.out.println("The 'files' directory does not exist or is not a directory.");
                // Create directory if it doesn't exist
                directory.mkdir();
                System.out.println("Created 'files' directory.");
                return;
            }
            
            // Get all files in the directory
            File[] files = directory.listFiles();
            
            // Create StringBuilder to build JSON string manually
            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.append("[\n");
            
            boolean firstFile = true;
            
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) { // Make sure it's a file, not a directory
                        if (!firstFile) {
                            jsonBuilder.append(",\n");
                        } else {
                            firstFile = false;
                        }
                        
                        String fileInfo = getFileInfoJson(file);
                        jsonBuilder.append(fileInfo);
                        
                        // Print progress to console
                        System.out.println("Processed: " + file.getName());
                    }
                }
            }
            
            jsonBuilder.append("\n]");
            
            // Write JSON to file
            try (FileWriter jsonFile = new FileWriter("files.json")) {
                jsonFile.write(jsonBuilder.toString());
                jsonFile.flush();
            }
            
            System.out.println("File information successfully written to files.json");
            
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static String getFileInfoJson(File file) throws IOException, NoSuchAlgorithmException {
        StringBuilder fileInfo = new StringBuilder();
        fileInfo.append("  {\n");
        
        // Get file name
        fileInfo.append("    \"filename\": \"").append(escapeJsonString(file.getName())).append("\",\n");
        
        // Get file size in readable format
        long sizeInBytes = file.length();
        fileInfo.append("    \"size\": \"").append(formatFileSize(sizeInBytes)).append("\",\n");
        
        // Get file date
        Path path = Paths.get(file.getAbsolutePath());
        BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
        Date fileDate = new Date(attrs.lastModifiedTime().toMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        fileInfo.append("    \"date\": \"").append(dateFormat.format(fileDate)).append("\",\n");
        
        // Calculate SHA-256 hash
        String sha256Hash = calculateSHA256(file);
        fileInfo.append("    \"sha256\": \"").append(sha256Hash).append("\"\n");
        
        fileInfo.append("  }");
        return fileInfo.toString();
    }
    
    private static String escapeJsonString(String input) {
        // Basic JSON string escaping
        return input.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
    }
    
    private static String formatFileSize(long sizeInBytes) {
        // Format file size to KB, MB, or GB for readability
        final double KB = 1024.0;
        final double MB = KB * 1024;
        final double GB = MB * 1024;
        
        if (sizeInBytes < KB) {
            return sizeInBytes + " B";
        } else if (sizeInBytes < MB) {
            return String.format("%.2f KB", sizeInBytes / KB);
        } else if (sizeInBytes < GB) {
            return String.format("%.2f MB", sizeInBytes / MB);
        } else {
            return String.format("%.2f GB", sizeInBytes / GB);
        }
    }
    
    private static String calculateSHA256(File file) throws IOException, NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        FileInputStream fis = new FileInputStream(file);
        byte[] byteArray = new byte[1024];
        int bytesCount;
        
        // Read file data and update in message digest
        while ((bytesCount = fis.read(byteArray)) != -1) {
            digest.update(byteArray, 0, bytesCount);
        }
        fis.close();
        
        // Get the hash's bytes
        byte[] bytes = digest.digest();
        
        // Convert bytes to hexadecimal format
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        
        return sb.toString();
    }
}