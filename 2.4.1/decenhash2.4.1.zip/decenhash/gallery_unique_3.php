<?php
// Configuration
$imageDir = 'images';
$votesDir = 'votes';
$salt = 'start';

// Create votes directory if it doesn't exist
if (!file_exists($votesDir)) {
    mkdir($votesDir, 0755, true);
}

// Get all image files from directory
$images = [];
if (is_dir($imageDir)) {
    foreach (scandir($imageDir) as $file) {
        if (in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $images[] = $file;
        }
    }
}

// Get client IP (handling proxies)
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'vote' && isset($_POST['image'])) {
        $image = basename($_POST['image']);
        $ipHash = hash('sha256', getClientIP() . $salt);
        
        $voteFile = "$votesDir/$image.votes";
        $votes = file_exists($voteFile) ? json_decode(file_get_contents($voteFile), true) : [];
        
        if ($_POST['vote'] === 'like') {
            if (!in_array($ipHash, $votes)) {
                $votes[] = $ipHash;
            }
        } elseif ($_POST['vote'] === 'dislike') {
            $votes = array_diff($votes, [$ipHash]);
        }
        
        file_put_contents($voteFile, json_encode($votes));
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_POST['action'] === 'check_like' && isset($_POST['image'])) {
        $image = basename($_POST['image']);
        $ipHash = hash('sha256', getClientIP() . $salt);
        
        $voteFile = "$votesDir/$image.votes";
        $liked = false;
        
        if (file_exists($voteFile)) {
            $votes = json_decode(file_get_contents($voteFile), true);
            $liked = in_array($ipHash, $votes);
        }
        
        echo json_encode(['liked' => $liked]);
        exit;
    }
    
    echo json_encode(['error' => 'Invalid request']);
    exit;
}

// Check if an image is liked by current user (for initial page load)
function isLiked($image) {
    global $votesDir, $salt;
    $voteFile = "$votesDir/$image.votes";
    if (!file_exists($voteFile)) return false;
    
    $ipHash = hash('sha256', getClientIP() . $salt);
    $votes = json_decode(file_get_contents($voteFile), true);
    return in_array($ipHash, $votes);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Viewer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f5f5;
            color: #333;
        }

        .gallery-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }

        .thumbnail-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }

        .thumbnail {
            cursor: pointer;
            transition: transform 0.3s ease;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            aspect-ratio: 1;
            position: relative;
        }

        .thumbnail:hover {
            transform: scale(1.03);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .thumbnail img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .image-viewer {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }

        .image-viewer.active {
            opacity: 1;
            pointer-events: all;
        }

        #fullImage {
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
        }

        .close-btn {
            position: absolute;
            top: 20px;
            right: 30px;
            color: white;
            font-size: 40px;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .close-btn:hover {
            transform: scale(1.2);
        }

        .vote-buttons {
            position: absolute;
            bottom: 30px;
            right: 30px;
            display: flex;
            gap: 15px;
        }

        .vote-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            cursor: pointer;
            font-size: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }

        .vote-btn:hover {
            transform: scale(1.1);
        }

        .vote-btn.like.active {
            background-color: #4CAF50;
        }

        .vote-btn.dislike.active {
            background-color: #F44336;
        }

        @media (max-width: 768px) {
            .thumbnail-list {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            
            .vote-buttons {
                bottom: 15px;
                right: 15px;
            }
            
            .vote-btn {
                width: 40px;
                height: 40px;
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="gallery-container">
        <div class="thumbnail-list">
            <?php foreach ($images as $image): ?>
                <div class="thumbnail" data-image="<?= htmlspecialchars($image) ?>">
                    <img src="<?= htmlspecialchars("$imageDir/$image") ?>" alt="<?= htmlspecialchars($image) ?>">
                    <?php if (isLiked($image)): ?>
                        <div class="like-badge" style="position: absolute; top: 10px; right: 10px; color: #4CAF50; font-size: 20px;">
                            <i class="fas fa-thumbs-up"></i>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="image-viewer" id="imageViewer">
        <div class="close-btn" id="closeBtn">&times;</div>
        <img id="fullImage" src="" alt="">
        <div class="vote-buttons">
            <button class="vote-btn dislike" id="dislikeBtn"><i class="fas fa-thumbs-down"></i></button>
            <button class="vote-btn like" id="likeBtn"><i class="fas fa-thumbs-up"></i></button>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const thumbnails = document.querySelectorAll('.thumbnail');
            const imageViewer = document.getElementById('imageViewer');
            const fullImage = document.getElementById('fullImage');
            const closeBtn = document.getElementById('closeBtn');
            const likeBtn = document.getElementById('likeBtn');
            const dislikeBtn = document.getElementById('dislikeBtn');
            
            let currentImage = '';
            
            // Open image viewer when thumbnail is clicked
            thumbnails.forEach(thumbnail => {
                thumbnail.addEventListener('click', function() {
                    const imageSrc = this.getAttribute('data-image');
                    currentImage = imageSrc;
                    
                    fullImage.src = `images/${imageSrc}`;
                    imageViewer.classList.add('active');
                    
                    // Check if image is already liked
                    checkLikeStatus(imageSrc);
                });
            });
            
            // Close image viewer
            closeBtn.addEventListener('click', function() {
                imageViewer.classList.remove('active');
            });
            
            // Close when clicking outside the image
            imageViewer.addEventListener('click', function(e) {
                if (e.target === imageViewer) {
                    imageViewer.classList.remove('active');
                }
            });
            
            // Like button functionality
            likeBtn.addEventListener('click', function() {
                if (!currentImage) return;
                
                if (likeBtn.classList.contains('active')) {
                    // Already liked - remove like
                    sendVote('dislike');
                    likeBtn.classList.remove('active');
                } else {
                    // Like the image
                    sendVote('like');
                    likeBtn.classList.add('active');
                    dislikeBtn.classList.remove('active');
                }
            });
            
            // Dislike button functionality
            dislikeBtn.addEventListener('click', function() {
                if (!currentImage) return;
                
                if (dislikeBtn.classList.contains('active')) {
                    // Already disliked - remove dislike
                    sendVote('like');
                    dislikeBtn.classList.remove('active');
                } else {
                    // Dislike the image
                    sendVote('dislike');
                    dislikeBtn.classList.add('active');
                    likeBtn.classList.remove('active');
                }
            });
            
            // Keyboard navigation
            document.addEventListener('keydown', function(e) {
                if (!imageViewer.classList.contains('active')) return;
                
                if (e.key === 'Escape') {
                    imageViewer.classList.remove('active');
                } else if (e.key === 'ArrowRight') {
                    // Next image
                    navigateImage(1);
                } else if (e.key === 'ArrowLeft') {
                    // Previous image
                    navigateImage(-1);
                }
            });
            
            // Function to send vote to server
            function sendVote(vote) {
                fetch(window.location.href, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=vote&vote=${vote}&image=${encodeURIComponent(currentImage)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) {
                        console.error('Failed to register vote');
                    }
                });
            }
            
            // Function to check like status from server
            function checkLikeStatus(image) {
                fetch(window.location.href, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=check_like&image=${encodeURIComponent(image)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.liked) {
                        likeBtn.classList.add('active');
                        dislikeBtn.classList.remove('active');
                    } else {
                        likeBtn.classList.remove('active');
                        dislikeBtn.classList.remove('active');
                    }
                });
            }
            
            // Function to navigate between images
            function navigateImage(direction) {
                const thumbnailsArray = Array.from(thumbnails);
                const currentIndex = thumbnailsArray.findIndex(t => t.getAttribute('data-image') === currentImage);
                const newIndex = (currentIndex + direction + thumbnailsArray.length) % thumbnailsArray.length;
                
                const newImage = thumbnailsArray[newIndex].getAttribute('data-image');
                currentImage = newImage;
                fullImage.src = `images/${newImage}`;
                
                // Check like status for new image
                checkLikeStatus(newImage);
            }
        });
    </script>
</body>
</html>