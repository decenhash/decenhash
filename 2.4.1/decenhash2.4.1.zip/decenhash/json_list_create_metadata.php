<?php
function getFileHash($filepath) {
    return hash_file('sha256', $filepath);
}

function formatSizeUnits($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        return $bytes . ' bytes';
    } elseif ($bytes == 1) {
        return $bytes . ' byte';
    } else {
        return '0 bytes';
    }
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process'])) {
    // Get metadata values from the form
    $metadata = [
        'file_url' => $_POST['file_url'] ?? '',
        'username' => $_POST['username'] ?? '',
        'PIX' => $_POST['pix'] ?? '',
        'BTC' => $_POST['btc'] ?? '',
        'other_url' => $_POST['other_url'] ?? ''
    ];
    
    // Process the uploads with the provided metadata
    $result = processUploadsFolder('uploads', $metadata);
    
} else {
    // Display the form if not submitted
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>File Processor</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
            }
            .form-group {
                margin-bottom: 15px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            input[type="text"] {
                width: 100%;
                padding: 8px;
                box-sizing: border-box;
            }
            input[type="submit"] {
                background-color: #4CAF50;
                color: white;
                padding: 10px 15px;
                border: none;
                cursor: pointer;
                font-size: 16px;
            }
            input[type="submit"]:hover {
                background-color: #45a049;
            }
        </style>
    </head>
    <body>
        <h2>Enter Metadata Information</h2>
        <p>This information will be added to all processed JSON files.</p>
        
        <form method="post">
            <div class="form-group">
                <label for="file_url">File URL:</label>
                <input type="text" id="file_url" name="file_url">
            </div>
            
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username">
            </div>
            
            <div class="form-group">
                <label for="pix">PIX:</label>
                <input type="text" id="pix" name="pix">
            </div>
            
            <div class="form-group">
                <label for="btc">BTC:</label>
                <input type="text" id="btc" name="btc">
            </div>
            
            <div class="form-group">
                <label for="other_url">Other URL:</label>
                <input type="text" id="other_url" name="other_url">
            </div>
            
            <input type="submit" name="process" value="Process Files">
        </form>
    </body>
    </html>
    <?php
    exit;
}

function processUploadsFolder($uploadsDir = 'uploads', $metadata = []) {
    if (!is_dir($uploadsDir)) {
        return ['error' => 'Uploads directory does not exist'];
    }
    
    // Create data_search_json directory if it doesn't exist
    $jsonDir = 'data_search_json';
    if (!is_dir($jsonDir)) {
        if (!mkdir($jsonDir, 0755, true)) {
            return ['error' => 'Failed to create JSON directory'];
        }
    }
    
    $files = scandir($uploadsDir);
    $fileData = [];
    
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;
        
        $filePath = $uploadsDir . DIRECTORY_SEPARATOR . $file;
        if (!is_file($filePath)) continue;
        
        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        if (empty($fileExtension)) continue;
        
        $fileSize = filesize($filePath);
        $modifiedTime = filemtime($filePath);
        
        $fileData[$fileExtension][] = [
            'filename' => $file,
            'file_hash' => getFileHash($filePath),
            'file_extension' => $fileExtension,
            'date' => date('Y-m-d H:i:s', $modifiedTime),
            'file_size' => formatSizeUnits($fileSize),
            '_metadata' => $metadata
        ];
    }
    
    foreach ($fileData as $extension => $entries) {
        $chunks = array_chunk($entries, 20);
        
        foreach ($chunks as $index => $chunk) {
            $jsonData = json_encode($chunk, JSON_PRETTY_PRINT);
            $jsonSize = strlen($jsonData);
            
            $baseFilename = $extension . '.json';
            if ($index > 0 || $jsonSize > 20480) { // 20KB = 20480 bytes
                $baseFilename = $extension . '_' . $index . '.json';
            }
            
            $outputPath = $jsonDir . DIRECTORY_SEPARATOR . $baseFilename;
            file_put_contents($outputPath, $jsonData);
        }
    }
    
    return [
        'success' => 'Files processed successfully', 
        'json_location' => $jsonDir,
        'metadata_added' => $metadata
    ];
}

// Only execute if the form was submitted
if (isset($result)) {
    echo '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 20px auto; padding: 20px; background-color: #f0f0f0; border-radius: 5px;">';
    echo '<h2>Processing Result</h2>';
    
    if (isset($result['error'])) {
        echo '<p style="color: red;">' . $result['error'] . '</p>';
    } else {
        echo '<p style="color: green;">' . $result['success'] . '</p>';
        echo '<p>JSON files created in: ' . $result['json_location'] . '</p>';
        
        echo '<h3>Metadata Added:</h3>';
        echo '<ul>';
        foreach ($result['metadata_added'] as $key => $value) {
            echo '<li><strong>' . htmlspecialchars($key) . ':</strong> ' . htmlspecialchars($value) . '</li>';
        }
        echo '</ul>';
        
        echo '<p><a href="' . $_SERVER['PHP_SELF'] . '">Process more files</a></p>';
    }
    echo '</div>';
}
?>