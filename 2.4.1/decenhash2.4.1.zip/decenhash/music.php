<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Music Playlist</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <style>
        :root {
            --primary: #1db954;
            --dark: #121212;
            --light: #ffffff;
            --secondary: #282828;
            --text-grey: #b3b3b3;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', sans-serif;
        }
        
        body {
            background-color: var(--dark);
            color: var(--light);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
            border-bottom: 1px solid var(--secondary);
            margin-bottom: 30px;
        }
        
        header h1 {
            font-size: 28px;
            font-weight: 700;
        }
        
        .logo {
            color: var(--primary);
            margin-right: 10px;
        }
        
        .playlist {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 100px;
        }
        
        .track-card {
            background-color: var(--secondary);
            border-radius: 8px;
            overflow: hidden;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .track-card:hover {
            background-color: #333;
            transform: translateY(-5px);
        }
        
        .track-card.active {
            box-shadow: 0 0 0 2px var(--primary);
        }
        
        .track-image {
            width: 100%;
            aspect-ratio: 1;
            object-fit: cover;
            background-color: #444;
            position: relative;
            overflow: hidden;
        }
        
        .track-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .play-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .track-card:hover .play-overlay {
            opacity: 1;
        }
        
        .play-overlay i {
            font-size: 40px;
            color: var(--light);
        }
        
        .track-info {
            padding: 15px;
        }
        
        .track-title {
            font-weight: 600;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .track-artist {
            font-size: 14px;
            color: var(--text-grey);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .player {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: var(--secondary);
            padding: 15px 20px;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.3);
            display: flex;
            align-items: center;
            z-index: 100;
        }
        
        .player-track-info {
            display: flex;
            align-items: center;
            width: 30%;
        }
        
        .player-track-image {
            width: 56px;
            height: 56px;
            border-radius: 4px;
            margin-right: 15px;
            background-color: #444;
            overflow: hidden;
        }
        
        .player-track-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .player-track-details {
            overflow: hidden;
        }
        
        .player-track-title {
            font-weight: 500;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .player-track-artist {
            font-size: 12px;
            color: var(--text-grey);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .player-controls {
            width: 40%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .player-buttons {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }
        
        .player-button {
            background: none;
            border: none;
            color: var(--light);
            cursor: pointer;
            font-size: 16px;
            margin: 0 15px;
        }
        
        .player-button.main {
            font-size: 32px;
            color: var(--primary);
        }
        
        .player-button:hover {
            color: var(--primary);
        }
        
        .progress-container {
            width: 100%;
            display: flex;
            align-items: center;
        }
        
        .progress-time {
            font-size: 12px;
            color: var(--text-grey);
            min-width: 40px;
        }
        
        .progress-bar {
            flex-grow: 1;
            height: 4px;
            background-color: #5e5e5e;
            border-radius: 2px;
            margin: 0 10px;
            cursor: pointer;
            position: relative;
        }
        
        .progress {
            height: 100%;
            background-color: var(--primary);
            border-radius: 2px;
            width: 0;
        }
        
        .player-options {
            width: 30%;
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }
        
        .volume-container {
            display: flex;
            align-items: center;
        }
        
        .volume-icon {
            color: var(--text-grey);
            margin-right: 10px;
        }
        
        .volume-slider {
            width: 100px;
            height: 4px;
            background-color: #5e5e5e;
            border-radius: 2px;
            position: relative;
            cursor: pointer;
        }
        
        .volume-level {
            height: 100%;
            background-color: var(--primary);
            border-radius: 2px;
            width: 70%;
        }
        
        @media (max-width: 768px) {
            .playlist {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            
            .player {
                flex-direction: column;
                padding: 10px;
            }
            
            .player-track-info, .player-controls, .player-options {
                width: 100%;
                margin-bottom: 10px;
            }
            
            .player-options {
                justify-content: center;
            }
        }

        .no-music-message {
            text-align: center;
            color: var(--text-grey);
            padding: 40px 0;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <?php
    // Function to get all MP3 files from the 'musics' folder
    function getMusicFiles() {
        $musicPath = 'musics/';
        $files = [];
        
        // Check if directory exists
        if (!is_dir($musicPath)) {
            return $files;
        }
        
        // Get all MP3 files
        $allFiles = scandir($musicPath);
        foreach ($allFiles as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'mp3') {
                $files[] = $file;
            }
        }
        
        return $files;
    }
    
    // Function to get thumbnail for a music file
    function getThumbnail($filename) {
        // Extract the part before the hyphen
        $parts = explode('-', $filename);
        if (count($parts) > 0) {
            $artist = $parts[0];
            $thumbnailPath = 'musics/' . $artist . '.jpg';
            
            // Check if thumbnail exists
            if (file_exists($thumbnailPath)) {
                return $thumbnailPath;
            }
        }
        
        // Return a default thumbnail if specific one doesn't exist
        return 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/svgs/solid/music.svg';
    }
    
    // Function to get song title from filename
    function getSongTitle($filename) {
        $parts = explode('-', $filename);
        if (count($parts) > 1) {
            return pathinfo($parts[1], PATHINFO_FILENAME);
        }
        return pathinfo($filename, PATHINFO_FILENAME);
    }
    
    // Function to get artist name from filename
    function getArtistName($filename) {
        $parts = explode('-', $filename);
        if (count($parts) > 0) {
            return $parts[0];
        }
        return "Unknown Artist";
    }
    
    // Get all music files
    $musicFiles = getMusicFiles();
    ?>

    <div class="container">
        <header>
            <h1><i class="fas fa-headphones logo"></i> Music Playlist</h1>
        </header>
        
        <div class="playlist">
            <?php if (empty($musicFiles)): ?>
                <div class="no-music-message">
                    <p>No music files found in the 'musics' folder. Please add some MP3 files.</p>
                </div>
            <?php else: ?>
                <?php foreach ($musicFiles as $index => $file): ?>
                    <?php 
                        $thumbnail = getThumbnail($file);
                        $title = getSongTitle($file);
                        $artist = getArtistName($file);
                    ?>
                    <div class="track-card" data-index="<?php echo $index; ?>" data-file="musics/<?php echo $file; ?>" data-title="<?php echo $title; ?>" data-artist="<?php echo $artist; ?>" data-thumbnail="<?php echo $thumbnail; ?>">
                        <div class="track-image">
                            <img src="<?php echo $thumbnail; ?>" alt="<?php echo $title; ?>">
                            <div class="play-overlay">
                                <i class="fas fa-play"></i>
                            </div>
                        </div>
                        <div class="track-info">
                            <div class="track-title"><?php echo $title; ?></div>
                            <div class="track-artist"><?php echo $artist; ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="player">
        <div class="player-track-info">
            <div class="player-track-image">
                <img id="current-thumbnail" src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/svgs/solid/music.svg" alt="Current track">
            </div>
            <div class="player-track-details">
                <div id="current-title" class="player-track-title">Select a track</div>
                <div id="current-artist" class="player-track-artist">to start playing</div>
            </div>
        </div>
        <div class="player-controls">
            <div class="player-buttons">
                <button id="prev-button" class="player-button"><i class="fas fa-step-backward"></i></button>
                <button id="play-button" class="player-button main"><i class="fas fa-play"></i></button>
                <button id="next-button" class="player-button"><i class="fas fa-step-forward"></i></button>
            </div>
            <div class="progress-container">
                <div id="current-time" class="progress-time">0:00</div>
                <div id="progress-bar" class="progress-bar">
                    <div id="progress" class="progress"></div>
                </div>
                <div id="duration" class="progress-time">0:00</div>
            </div>
        </div>
        <div class="player-options">
            <div class="volume-container">
                <div class="volume-icon">
                    <i class="fas fa-volume-up"></i>
                </div>
                <div id="volume-slider" class="volume-slider">
                    <div id="volume-level" class="volume-level"></div>
                </div>
            </div>
        </div>
    </div>

    <audio id="audio-player"></audio>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const audioPlayer = document.getElementById('audio-player');
            const playButton = document.getElementById('play-button');
            const prevButton = document.getElementById('prev-button');
            const nextButton = document.getElementById('next-button');
            const progressBar = document.getElementById('progress-bar');
            const progress = document.getElementById('progress');
            const currentTime = document.getElementById('current-time');
            const duration = document.getElementById('duration');
            const currentThumbnail = document.getElementById('current-thumbnail');
            const currentTitle = document.getElementById('current-title');
            const currentArtist = document.getElementById('current-artist');
            const volumeSlider = document.getElementById('volume-slider');
            const volumeLevel = document.getElementById('volume-level');
            const trackCards = document.querySelectorAll('.track-card');
            
            let isPlaying = false;
            let currentTrackIndex = 0;
            let tracks = [];
            
            // Collect all tracks data
            trackCards.forEach((card, index) => {
                tracks.push({
                    index: index,
                    file: card.dataset.file,
                    title: card.dataset.title,
                    artist: card.dataset.artist,
                    thumbnail: card.dataset.thumbnail
                });
                
                // Add click event to track cards
                card.addEventListener('click', function() {
                    currentTrackIndex = this.dataset.index;
                    loadTrack(currentTrackIndex);
                    playTrack();
                });
            });
            
            // Function to load a track
            function loadTrack(index) {
                const track = tracks[index];
                if (!track) return;
                
                // Reset active class on all tracks
                trackCards.forEach(card => {
                    card.classList.remove('active');
                });
                
                // Add active class to current track
                trackCards[index].classList.add('active');
                
                // Update player info
                audioPlayer.src = track.file;
                currentThumbnail.src = track.thumbnail;
                currentTitle.textContent = track.title;
                currentArtist.textContent = track.artist;
                
                // Reset progress
                progress.style.width = '0%';
                currentTime.textContent = '0:00';
                
                // Get duration after metadata is loaded
                audioPlayer.addEventListener('loadedmetadata', function() {
                    duration.textContent = formatTime(audioPlayer.duration);
                });
            }
            
            // Function to play track
            function playTrack() {
                audioPlayer.play();
                isPlaying = true;
                playButton.innerHTML = '<i class="fas fa-pause"></i>';
            }
            
            // Function to pause track
            function pauseTrack() {
                audioPlayer.pause();
                isPlaying = false;
                playButton.innerHTML = '<i class="fas fa-play"></i>';
            }
            
            // Function to play next track
            function nextTrack() {
                currentTrackIndex++;
                if (currentTrackIndex >= tracks.length) {
                    currentTrackIndex = 0;
                }
                loadTrack(currentTrackIndex);
                playTrack();
            }
            
            // Function to play previous track
            function prevTrack() {
                currentTrackIndex--;
                if (currentTrackIndex < 0) {
                    currentTrackIndex = tracks.length - 1;
                }
                loadTrack(currentTrackIndex);
                playTrack();
            }
            
            // Function to format time
            function formatTime(seconds) {
                const minutes = Math.floor(seconds / 60);
                const secs = Math.floor(seconds % 60);
                return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
            }
            
            // Play/Pause button event
            playButton.addEventListener('click', function() {
                if (tracks.length === 0) return;
                
                if (!audioPlayer.src) {
                    loadTrack(0);
                }
                
                if (isPlaying) {
                    pauseTrack();
                } else {
                    playTrack();
                }
            });
            
            // Next button event
            nextButton.addEventListener('click', function() {
                if (tracks.length === 0) return;
                nextTrack();
            });
            
            // Previous button event
            prevButton.addEventListener('click', function() {
                if (tracks.length === 0) return;
                prevTrack();
            });
            
            // Progress bar update
            audioPlayer.addEventListener('timeupdate', function() {
                const percentage = (audioPlayer.currentTime / audioPlayer.duration) * 100;
                progress.style.width = `${percentage}%`;
                currentTime.textContent = formatTime(audioPlayer.currentTime);
            });
            
            // Click on progress bar to seek
            progressBar.addEventListener('click', function(e) {
                const width = this.clientWidth;
                const clickX = e.offsetX;
                const duration = audioPlayer.duration;
                
                audioPlayer.currentTime = (clickX / width) * duration;
            });
            
            // Volume control
            volumeSlider.addEventListener('click', function(e) {
                const width = this.clientWidth;
                const clickX = e.offsetX;
                const volume = clickX / width;
                
                audioPlayer.volume = volume;
                volumeLevel.style.width = `${volume * 100}%`;
            });
            
            // When track ends, play next one
            audioPlayer.addEventListener('ended', function() {
                nextTrack();
            });
            
            // Set initial volume
            audioPlayer.volume = 0.7;
            volumeLevel.style.width = '70%';
            
            // If there are tracks, load the first one
            if (tracks.length > 0) {
                loadTrack(0);
            }
        });
    </script>
</body>
</html>