<?php
// Define the directory to scan
$directory = 'files';

// Check if directory exists
if (!is_dir($directory)) {
    die("Error: Directory '$directory' does not exist.");
}

// Initialize an array to hold files grouped by extension
$filesByExtension = [];

// Scan the directory
$files = scandir($directory);

foreach ($files as $file) {
    // Skip current and parent directory entries
    if ($file === '.' || $file === '..') {
        continue;
    }
    
    $filePath = $directory . '/' . $file;
    
    // Skip directories (only process files)
    if (is_dir($filePath)) {
        continue;
    }
    
    // Get file information
    $pathInfo = pathinfo($filePath);
    $extension = isset($pathInfo['extension']) ? strtolower($pathInfo['extension']) : 'none';
    
    // Generate a simple hash of the file (for demonstration)
    $fileHash = md5_file($filePath);
    
    // Create file metadata
    $fileData = [
        'filename' => $file,
        'user' => get_current_user(), // Current system user
        'date' => date('Y-m-d', filemtime($filePath)), // Last modified date
        'hash' => $fileHash,
        'extension' => $extension,
        'link' => "files/$file",
        'url' => "",
        'description' => "" // Empty description by default
    ];
    
    // Add to the appropriate extension group
    if (!isset($filesByExtension[$extension])) {
        $filesByExtension[$extension] = [];
    }
    $filesByExtension[$extension][] = $fileData;
}

// Create JSON files for each extension
foreach ($filesByExtension as $extension => $files) {
    $jsonData = [
        'files' => $files
    ];
    
    $jsonFileName = ($extension === 'none') ? 'no_extension.json' : "$extension.json";
    
    // Write JSON to file
    file_put_contents('data_json/' . $jsonFileName, json_encode($jsonData, JSON_PRETTY_PRINT));
    
    echo "Created JSON file: $jsonFileName with " . count($files) . " entries.\n";
}

echo "Processing complete.\n";
?>