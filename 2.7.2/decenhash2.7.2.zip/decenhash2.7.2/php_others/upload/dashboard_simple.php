<?php
// Database configuration for SQL payment mode
include 'db_config.php';

// Database configuration
define('DB_HOST', $db_config['host']);
define('DB_USER', $db_config['username']);
define('DB_PASS', $db_config['password']);
define('DB_NAME', $db_config['database']);


// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get statistics
$stats = array();

// 1. Files with most deposits
$query = "SELECT filehash, extension, SUM(deposit) as total_deposit 
          FROM blocks 
          GROUP BY filehash, extension 
          ORDER BY total_deposit DESC 
          LIMIT 5";
$result = $conn->query($query);
$stats['top_files'] = $result->fetch_all(MYSQLI_ASSOC);

// 2. Last file added
$query = "SELECT filehash, extension, user, deposit, timestamp 
          FROM blocks 
          ORDER BY timestamp DESC 
          LIMIT 1";
$result = $conn->query($query);
$stats['last_file'] = $result->fetch_assoc();

// 3. Percentage of top file vs all others
$query = "SELECT 
            (SELECT SUM(deposit) FROM blocks WHERE filehash = ?) as top_file_deposit,
            (SELECT SUM(deposit) FROM blocks WHERE filehash != ?) as other_files_deposit";
$stmt = $conn->prepare($query);
$top_file_hash = $stats['top_files'][0]['filehash'];
$stmt->bind_param("ss", $top_file_hash, $top_file_hash);
$stmt->execute();
$result = $stmt->get_result();
$deposit_data = $result->fetch_assoc();

if ($deposit_data['other_files_deposit'] > 0) {
    $percentage = ($deposit_data['top_file_deposit'] / $deposit_data['other_files_deposit']) * 100;
} else {
    $percentage = 100;
}
$stats['top_vs_others'] = round($percentage, 2);

// 4. Total deposits
$query = "SELECT SUM(deposit) as total_deposits FROM blocks";
$result = $conn->query($query);
$stats['total_deposits'] = $result->fetch_assoc()['total_deposits'];

// 5. Payment method distribution
$query = "SELECT 
            SUM(CASE WHEN btc IS NOT NULL THEN 1 ELSE 0 END) as btc_count,
            SUM(CASE WHEN pix IS NOT NULL THEN 1 ELSE 0 END) as pix_count,
            COUNT(*) as total_count
          FROM blocks";
$result = $conn->query($query);
$payment_stats = $result->fetch_assoc();
$stats['btc_percentage'] = round(($payment_stats['btc_count'] / $payment_stats['total_count']) * 100, 2);
$stats['pix_percentage'] = round(($payment_stats['pix_count'] / $payment_stats['total_count']) * 100, 2);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Deposit Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            margin-bottom: 20px;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .stat-card {
            text-align: center;
            padding: 20px;
        }
        .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
        }
        .stat-label {
            color: #6c757d;
            font-size: 1rem;
        }
        .bg-custom-1 {
            background-color: #4e73df;
            color: white;
        }
        .bg-custom-2 {
            background-color: #1cc88a;
            color: white;
        }
        .bg-custom-3 {
            background-color: #36b9cc;
            color: white;
        }
        .bg-custom-4 {
            background-color: #f6c23e;
            color: white;
        }
        .dashboard-header {
            padding: 20px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid #e3e6f0;
        }
        .file-icon {
            font-size: 2rem;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="dashboard-header">
            <h1><i class="bi bi-graph-up"></i> File Deposit Dashboard</h1>
            <p class="text-muted">Analytics and statistics for deposited files</p>
        </div>

        <div class="row">
            <!-- Total Deposits Card -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-custom-1">
                    <div class="stat-card">
                        <div class="stat-value">$<?= number_format($stats['total_deposits'], 2) ?></div>
                        <div class="stat-label">TOTAL DEPOSITS</div>
                        <i class="bi bi-currency-dollar file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- Top File Percentage Card -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-custom-2">
                    <div class="stat-card">
                        <div class="stat-value"><?= $stats['top_vs_others'] ?>%</div>
                        <div class="stat-label">TOP FILE VS OTHERS</div>
                        <i class="bi bi-percent file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- BTC Payments Card -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-custom-3">
                    <div class="stat-card">
                        <div class="stat-value"><?= $stats['btc_percentage'] ?>%</div>
                        <div class="stat-label">BTC PAYMENTS</div>
                        <i class="bi bi-currency-bitcoin file-icon"></i>
                    </div>
                </div>
            </div>

            <!-- PIX Payments Card -->
            <div class="col-xl-3 col-md-6">
                <div class="card bg-custom-4">
                    <div class="stat-card">
                        <div class="stat-value"><?= $stats['pix_percentage'] ?>%</div>
                        <div class="stat-label">PIX PAYMENTS</div>
                        <i class="bi bi-qr-code file-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Top Files by Deposit -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-trophy-fill"></i> Top Files by Deposit Amount</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>File</th>
                                        <th>Extension</th>
                                        <th>Total Deposit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($stats['top_files'] as $file): ?>
                                    <tr>
                                        <td><?= substr($file['filehash'], 0, 8) ?>...</td>
                                        <td><?= strtoupper($file['extension']) ?></td>
                                        <td>$<?= number_format($file['total_deposit'], 2) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Last Added File -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-clock-fill"></i> Last Added File</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($stats['last_file']): ?>
                        <div class="mb-3">
                            <strong>File Hash:</strong> <?= substr($stats['last_file']['filehash'], 0, 12) ?>...
                        </div>
                        <div class="mb-3">
                            <strong>Extension:</strong> <?= strtoupper($stats['last_file']['extension']) ?>
                        </div>
                        <div class="mb-3">
                            <strong>User:</strong> <?= htmlspecialchars($stats['last_file']['user']) ?>
                        </div>
                        <div class="mb-3">
                            <strong>Deposit:</strong> $<?= number_format($stats['last_file']['deposit'], 2) ?>
                        </div>
                        <div class="mb-3">
                            <strong>Timestamp:</strong> <?= date('M j, Y H:i:s', strtotime($stats['last_file']['timestamp'])) ?>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-info">No files found in the database.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Deposit Distribution Chart -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="bi bi-pie-chart-fill"></i> Deposit Distribution</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="depositChart" height="100"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Prepare data for the chart
        const topFileDeposit = <?= $deposit_data['top_file_deposit'] ?? 0 ?>;
        const otherFilesDeposit = <?= $deposit_data['other_files_deposit'] ?? 0 ?>;
        
        // Create chart
        const ctx = document.getElementById('depositChart').getContext('2d');
        const depositChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Top File (<?= substr($stats['top_files'][0]['filehash'] ?? '', 0, 8) ?>...)', 'All Other Files'],
                datasets: [{
                    data: [topFileDeposit, otherFilesDeposit],
                    backgroundColor: [
                        'rgba(78, 115, 223, 0.8)',
                        'rgba(28, 200, 138, 0.8)'
                    ],
                    hoverBackgroundColor: [
                        'rgba(78, 115, 223, 1)',
                        'rgba(28, 200, 138, 1)'
                    ],
                    hoverBorderColor: "rgba(234, 236, 244, 1)",
                }],
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += '$' + context.raw.toFixed(2);
                                label += ' (' + Math.round(context.parsed * 100 / (topFileDeposit + otherFilesDeposit)) + '%)';
                                return label;
                            }
                        }
                    },
                    legend: {
                        position: 'bottom',
                    }
                },
                cutout: '70%',
            },
        });
    </script>
</body>
</html>