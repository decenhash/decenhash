﻿<?php

session_start();

// Max size of each HTML page
$sizeLimit = 100 * 1024; // 100KB in bytes

// Allow finding pages based in the file extension and words in the filename
$morePages = 1; 

if (empty($_GET) && empty($_POST)) {

    echo "<div align='right'>";    
    echo " <a href='videos.html' style='color:#333;'>Videos</a> |";    
    echo " <a href='music.html' style='color:#333;'>Music</a> |"; 
    echo " <a href='php_others/groups/groups.html' style='color:#333;'>Groups</a> |"; 
    echo " <a href='decenhash2.7.1.zip' style='color:#333;'>Sourcecode</a> |";

    if (isset($_SESSION['user'])){        
        
        echo " <a href='logout.php' style='color:#333;'>Logout</a>"; 
        echo ", " . $_SESSION['user'];
        echo "</div><br>"; 

    } else {

        echo " <a href='login.php' style='color:#333;'>Login</a>";        
    }

    echo "</div><br>"; 
}

    function sha256($message) {
        return hash('sha256', $message);
    }

    // Function to handle search form submission
    function performSearch() {
        if (isset($_GET['search'])) {
            $searchInput = trim($_GET['search']);

            if (empty($searchInput)) return;

            // Check if input is already a valid SHA-256 hash (64 hex characters)
            $isValidHash = preg_match('/^[a-fA-F0-9]{64}$/', $searchInput);

            if ($isValidHash) {
                // If input is already a valid hash, use it directly
                $hash = $searchInput;
            } else {
                // Otherwise generate SHA-256 hash of the input
                $hash = sha256($searchInput);
            }

            if (file_exists("data/$hash/index.html")) {
                // Redirect to the page instead of including it
                header("Location: data/$hash/index.html");
                exit(); // Important to prevent further script execution
            } else {
                echo "File don't exists!"; die;
            }
        }
    }

    // Call the function when form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
        performSearch();
    }

    function check_sha256(string $input): string {
        $sha256_regex = '/^[a-f0-9]{64}$/'; // Regex for a 64-character hexadecimal string

        if (preg_match($sha256_regex, $input)) {
            return $input; // Input is a valid SHA256 hash
        } else {
            return hash('sha256', $input); // Input is not a valid SHA256 hash, return its hash
        }
    }

    if (isset($_GET['reply'])) {
        $reply = $_GET['reply'];
    } else {
        $reply = "";
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Configuration - Customize these paths and settings as needed
        $uploadDirBase = 'data'; // Base directory for all uploads
        $ownersDir = 'owners'; // Directory for BTC information
        $metadataDir = 'metadata'; // Directory for metadata JSON files

        // Create directories if they don't exist
        if (!is_dir($uploadDirBase)) {
            mkdir($uploadDirBase, 0777, true);
        }
        if (!is_dir($ownersDir)) {
            mkdir($ownersDir, 0777, true);
        }
        if (!is_dir($metadataDir)) {
            mkdir($metadataDir, 0777, true);
        }

        // Check if category was provided
        if (isset($_POST['category']) && !empty($_POST['category'])) {
            $categoryText = strtolower($_POST['category']);
            $fileContent = null;
            $originalFileName = null;
            $fileExtension = 'txt'; // Default extension for text content
            $isTextContent = false; // Flag to track if content is from text area

            // Check if a file was uploaded
            if (isset($_FILES['uploaded_file']) && $_FILES['uploaded_file']['error'] === UPLOAD_ERR_OK) {
                $uploadedFile = $_FILES['uploaded_file'];
                $fileContent = file_get_contents($uploadedFile['tmp_name']);
                $originalFileName = strtolower($uploadedFile['name']);
                $fileExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);
                $isTextContent = false;
            } elseif (isset($_POST['text_content']) && !empty($_POST['text_content'])) {
                // If no file uploaded, check for text content
                $fileContent = $_POST['text_content'];
                $date = date("Y.m.d H:i:s"); // Just for naming purposes in index.html

                if (stripos($fileNameWithExtension, 'http') !== 0) {
                    $relativePathToFile = 'https://' . $fileNameWithExtension;
                }
                
                $originalFileName = hash('sha256', $fileContent);
                $fileContentLen = strlen($fileContent);

                if ($fileContentLen > 50) {
                    $originalFileName = htmlspecialchars(substr($fileContent, 0, 50)) . " ($date)"; 
                } else {
                    $originalFileName = htmlspecialchars(substr($fileContent, 0, 50)) . " ($date)";
                }

                $isTextContent = true;
            }

            if ($fileContent !== null) { // Proceed if we have either file content or text content
                if (strtolower($fileExtension) === 'php') {
                    die('Error: PHP files are not allowed!');
                }

                if ($_POST['category'] == $_POST['text_content']) {
                    die ("Error: Category can't be the same of text contents.");
                }

                // Calculate SHA256 hashes
                $fileHash = hash('sha256', $fileContent);
                $categoryHash = check_sha256($categoryText);

                // Determine file extension (already done above, default is 'txt' for text content)
                $fileNameWithExtension = $fileHash . '.' . $fileExtension; // Hash + extension as filename

                // Construct directory paths
                $fileUploadDir = $uploadDirBase . '/' . $fileHash; // Folder name is file hash
                $categoryDir = $uploadDirBase . '/' . $categoryHash; // Folder name is category hash

                // Create directories if they don't exist
                if (!is_dir($fileUploadDir)) {
                    mkdir($fileUploadDir, 0777, true); // Create file hash folder
                }
                if (!is_dir($categoryDir)) {
                    mkdir($categoryDir, 0777, true); // Create category hash folder
                }

                // Save the content (either uploaded file or text content)
                $destinationFilePath = $fileUploadDir . '/' . $fileNameWithExtension;

                if (file_exists($destinationFilePath)) {
                    die('Error: File already exists!');
                }

                if ($isTextContent) {

                    $file = fopen($destinationFilePath, 'w');
                    fwrite($file, $fileContent);
                    fclose($file);                                          

                    if ($saveResult !== false) {
                        $fileSaved = true;
                    } else {
                        $fileSaved = false;
                    }
                } else {
                    $fileSaved = move_uploaded_file($uploadedFile['tmp_name'], $destinationFilePath); // Save uploaded file
                }

                if ($fileSaved) {
                    // Content saved successfully

                    // Save BTC information if provided
                    if (isset($_POST['btc']) && !empty($_POST['btc'])) {
                        $btcFilePath = $ownersDir . '/' . $fileHash;
                        if (!file_exists($btcFilePath)) {                            
                            $file = fopen($btcFilePath, 'w');
                            fwrite($file, $_POST['btc']);
                            fclose($file);                          
                        }
                    }

                    // Save metadata if all required fields are provided
                    if (isset($_POST['user']) && !empty($_POST['user']) &&
                        isset($_POST['title']) && !empty($_POST['title']) &&
                        isset($_POST['description']) && !empty($_POST['description']) &&
                        isset($_POST['url']) && !empty($_POST['url'])) {
                        
                        $metadata = [
                            'user' => $_POST['user'],
                            'title' => $_POST['title'],
                            'description' => $_POST['description'],
                            'url' => $_POST['url']
                        ];
                        
                        $metadataFilePath = $metadataDir . '/' . $fileHash . '.json';
                        if (!file_exists($metadataFilePath)) {                            
                            $file = fopen($metadataFilePath, 'w');
                            fwrite($file, json_encode($metadata, JSON_PRETTY_PRINT));
                            fclose($file);
                        }
                    }

                    // Create empty file in category folder with hash + extension name
                    $categoryFilePath = $categoryDir . '/' . $fileNameWithExtension; // Empty file name is file hash + extension inside category folder
                    if (touch($categoryFilePath)) {
                        // Empty file created successfully
                        
                        $contentHead = "<link rel='stylesheet' href='../../default.css'><script src='../../default.js'></script><script src='../../ads.js'></script><div id='ads' name='ads' class='ads'></div><div id='default' name='default' class='default'></div>";
 
                        // Handle index.html inside file hash folder (for content links)
                        $indexPathFileFolder = $fileUploadDir . '/index.html';

                        if (file_exists($indexPathFileFolder)){

                            $indexPathFileFolderSize = filesize($indexPathFileFolder);
                       
                            if ($indexPathFileFolderSize > $sizeLimit) {
                                 $currentDate = date('Ymd');
                                 $indexPathFileFolder = $fileUploadDir . '/index_' . $currentDate .  '.html';
                            } 
                        }

                        if (!file_exists($indexPathFileFolder)) {
                            $file = fopen($indexPathFileFolder, 'a');
                            fwrite($file, $contentHead);
                            fclose($file);
                        }

                        $fileImage = "";
                        $fileImageCategory = ""; 

                        if (isset($_POST['url']) && !empty($_POST['url'])) {
  
                            $fileImage = '<a href="' . htmlspecialchars($_POST['url']) . '"><img src="' . htmlspecialchars($_POST['url']) . '" width="100%"></a><br>';
                            $fileImageCategory = '<a href="' . htmlspecialchars($_POST['url']) . '"><img src="' . htmlspecialchars($_POST['url']) . '" width="100%"></a><br>';
                        }

                        if (strtolower($fileExtension) === 'jpg' || strtolower($fileExtension) === 'png') {
                            $fileImage = '<a href="' . htmlspecialchars($fileNameWithExtension) . '"><img src="' . htmlspecialchars($fileNameWithExtension) . '" width="100%"></a><br>';
                            $fileImageCategory = '<a href="../' . $fileHash . '/' . htmlspecialchars($fileNameWithExtension) . '"><img src="../' . $fileHash . '/' . htmlspecialchars($fileNameWithExtension) . '" width="100%"></a><br>';
                        }   

                        if ($isTextContent){
                            $fileNameWithExtension = $_POST['text_content'];

                            if (stripos($fileNameWithExtension, 'http') !== 0) {
                                $relativePathToFile = 'https://' . $fileNameWithExtension;
                            }
                        }                        

                        $linkLike = $fileImage . '<a href="../../like.php?reply=' . htmlspecialchars($fileHash) . '">' . "<img src='../../icons/thumb_up.png' alt='[ Like ]'>" . '</a> ';
                        $linkReply = $linkLike . '<a href="../../index.php?reply=' . htmlspecialchars($fileHash) . '">' . "<img src='../../icons/arrow_undo.png' alt='[ Reply ]'>" . '</a> ';
                        $linkToHash = $linkReply . '<a href="../' . htmlspecialchars($fileHash) . '/index.html">' . "<img src='../../icons/text_align_justity.png' alt='[ Open ]'>" . '</a> ';
                        $linkToFileFolderIndex = $linkToHash . '<a href="' . htmlspecialchars($fileNameWithExtension) . '">' . htmlspecialchars($originalFileName) . '</a><br>' ; //Use original file name or 'text_content.txt' for link text
                        
                        $indexContentFileFolder = file_get_contents($indexPathFileFolder);
                        if (strpos($indexContentFileFolder, $linkToFileFolderIndex) === false) {
                            $file = fopen($indexPathFileFolder, 'w');
                            fwrite($file, $indexContentFileFolder . $linkToFileFolderIndex);
                            fclose($file);  
                        }

                        // Handle index.html inside category folder (for link to original content)
                        $indexPathCategoryFolder = $categoryDir . '/index.html';

                        if (file_exists($indexPathCategoryFolder)){

                            $indexPathCategoryFolderSize = filesize($indexPathCategoryFolder);

                            if ($indexPathCategoryFolderSize > $sizeLimit) {
                                 $currentDate = date('Ymd');
                                 $indexPathCategoryFolder = $categoryDir . '/index_' . $currentDate .  '.html';
                            }
                        }

                        if (!file_exists($indexPathCategoryFolder)) {
                            $file = fopen($indexPathCategoryFolder, 'a');
                            fwrite($file, $contentHead);
                            fclose($file);                 
                        }

                        // Construct relative path to the content in the content hash folder
                        $relativePathToFile = '../' . $fileHash . '/' . $fileNameWithExtension;
                        
                        if ($isTextContent){
                            $relativePathToFile = $_POST['text_content'];

                            if (stripos($relativePathToFile, 'http') !== 0) {
                                $relativePathToFile = 'https://' . $relativePathToFile;
                            }

                        }  
   
                        $categoryLike = $fileImageCategory . '<a href="../../like.php?reply=' . htmlspecialchars($fileHash) . '">' . "<img src='../../icons/thumb_up.png' alt='[ Like ]'>" . '</a> ';
                        $categoryReply = $categoryLike . '<a href="../../index.php?reply=' . htmlspecialchars($fileHash) . '">' . "<img src='../../icons/arrow_undo.png' alt='[ Reply ]'>" . '</a> ';
                        $linkToHashCategory = $categoryReply . '<a href="../' . htmlspecialchars($fileHash) . '/index.html">' . "<img src='../../icons/text_align_justity.png' alt='[ Open ]'>" . '</a> ';
                        $linkToCategoryFolderIndex = $linkToHashCategory . '<a href="' . htmlspecialchars($relativePathToFile) . '">' . htmlspecialchars($originalFileName) . '</a><br>'; //Use original file name or 'text_content.txt' for link text
                        $indexContentCategoryFolder = file_get_contents($indexPathCategoryFolder);
                        if (strpos($indexContentCategoryFolder, $linkToCategoryFolderIndex) === false) {
                            $file = fopen($indexPathCategoryFolder, 'w');
                            fwrite($file, $indexContentCategoryFolder . $linkToCategoryFolderIndex);
                            fclose($file);  
                        }

                        if (isset($_SESSION['user'])){

                            $usernameHash = hash('sha256', $_SESSION['user']);
 
                            $fileUserFolder = 'files';

                            // Create directories if they don't exist
                            if (!is_dir($fileUserFolder)) {
                                mkdir($fileUserFolder, 0777, true);
                            }

                        $usernameFilePath = $fileUserFolder . '/'. $fileHash . '.txt';

                        $file = fopen($usernameFilePath, 'w');
                        fwrite($file, $usernameHash);
                        fclose($file);  
                        }                                      

                        if ($morePages == 1){
                            $originalFileName = strtolower($originalFileName);    

                            if (isset($_SESSION['user'])){
                                $originalFileName = $originalFileName . "_" . strtolower($_SESSION['user']);
                            }                        

                            $originalFileName = str_replace(" ", "_", $originalFileName);
                            $originalFileName = str_replace(".", "_", $originalFileName);

                            $pages = explode("_", $originalFileName);
                            $pages = array_map('trim', $pages);
                 
                            $folderFile = "";
  
                            // Upload file to each URL
                            foreach ($pages as $page) {

                                if ($page == $categoryText){continue;}
 
                                $pageHash = hash('sha256', $page);

                                $folder = "data/" . $pageHash;

                                $folderFile = $folder . '/index.html';

                                //echo $page . ' ' . $pageHash . ' ' . '<br>';
 
                                if (!is_dir($folder)) {
                                    mkdir($folder, 0777, true);
                                }                             
 
                                if (file_exists($folderFile)){

                                    $indexPathCategoryFolderSize = filesize($folderFile);

                                    if ($indexPathCategoryFolderSize > $sizeLimit) {
                                        $currentDate = date('Ymd');
                                        $folderFile = $folder . '/index_' . $currentDate .  '.html';
                                    }

                                $file = fopen($folderFile, 'a');
                                fwrite($file, $linkToCategoryFolderIndex);
                                fclose($file);  

                                } else {

                                $file = fopen($folderFile, 'a');
                                fwrite($file, $contentHead . $linkToCategoryFolderIndex);
                                fclose($file);  

                                }                           
                               
                            }
                        }
                    }

                    echo "<p class='success'>Content processed successfully!</p>";
                    echo "<p>Content saved in: <pre><a href='" . htmlspecialchars($indexPathCategoryFolder) . "'>$indexPathCategoryFolder</a></pre></p>";
                } else {
                    echo "<p class='error'>Error creating empty file in category folder.</p>";
                }
            } else {
                echo "<p class='error'>Error saving content.</p>";
            }
        } else {
            echo "<p class='error'>Please select a file or enter text content and provide a category.</p>";
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganhe dinheiro compartilhando arquivos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            line-height: 1.6;
            color: #333;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 50px;
        }
        .language-switcher {
            padding: 8px 16px;
            border: 1px solid #ccc;
            border-radius: 20px;
            background: white;
            cursor: pointer;
            font-size: 14px;
        }
        .contact-button {
            padding: 8px 16px;
            background-color: #FF7F00;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-weight: bold;
            color: white;
        }
        .main-content {
            max-width: 800px;
            margin: 0 auto;
        }
        .main-heading {
            font-size: 48px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .sub-heading {
            font-size: 24px;
            margin-bottom: 40px;
            color: #555;
        }
        .pricing-link {
            color: #FF7F00;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
        }
        .search-form, .upload-form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
        }
        input[type="text"], input[type="file"], input[type="url"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            background: #f9f9f9;
        }
        button[type="submit"], input[type="submit"] {
            background-color: #777;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            font-weight: normal;
        }
        .more-options-link {
            color: #555;
            text-decoration: none;
            cursor: pointer;
            display: inline-block;
            margin: 10px 0;
            font-size: 14px;
        }
        .optional-fields {
            display: none;
            margin-top: 15px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        .footer-links {
            text-align: center;
            margin: 30px 0;
        }
        .footer-links a {
            margin: 0 10px;
            text-decoration: none;
            color: #555;
            font-size: 14px;
        }
        .copyright {
            text-align: center;
            color: #999;
            font-size: 13px;
        }
        label {
            display: block;
            margin-top: 15px;
            color: #555;
            font-size: 14px;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 30px;
            border-radius: 8px;
            width: 80%;
            max-width: 500px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
        .payment-option {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .payment-option:hover {
            background-color: #f5f5f5;
        }
        .payment-option h3 {
            margin-top: 0;
            color: #333;
        }
        .payment-option img {
            height: 30px;
            vertical-align: middle;
            margin-right: 10px;
        }
        .copy-btn {
            background-color: #777;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 10px;
        }
        .payment-info {
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="header">
        <button class="contact-button" onclick="window.open('https://wa.me/5591986042104', '_blank')">Contato</button>
        <button id="languageButton" class="language-switcher">English</button>
    </div>

    <div class="main-content">
        <h1 class="main-heading">Ganhe dinheiro compartilhando arquivos</h1>
        <p class="sub-heading">Quanto mais likes e comentários você receber maiores são as suas recompensas. <span id="pricingLink" class="pricing-link">Adquira sua conta premium por apenas 25,00 R$</span></p>
        
        <!-- Modal de Pagamento -->
        <div id="paymentModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="modalTitle">Escolha sua forma de pagamento</h2>
                
                <div class="payment-option" onclick="selectPayment('pix')">
                    <h3><img src="https://logodownload.org/wp-content/uploads/2020/08/pix-banco-central-logo-1.png" alt="PIX"> PIX</h3>
                    <div class="payment-info" id="pix-info">
                        Chave PIX: decenhash@gmail.com
                        <button class="copy-btn" onclick="copyToClipboard('pix-info', event)">Copiar</button>
                    </div>
                    <p id="pixDesc">Pagamento instantâneo e sem taxas</p>
                </div>
                
                <div class="payment-option" onclick="selectPayment('paypal')">
                    <h3><img src="https://www.paypalobjects.com/webstatic/mktg/Logo/pp-logo-100px.png" alt="PayPal"> PayPal</h3>
                    <div class="payment-info">
                        <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ARHWVWR9M3H7E" target="_blank" id="paypalLink">Pagar via PayPal</a>
                    </div>
                    <p id="paypalDesc">Pagamento internacional com cartão</p>
                </div>
                
                <div class="payment-option" onclick="selectPayment('btc')">
                    <h3><img src="https://cryptologos.cc/logos/bitcoin-btc-logo.png" alt="Bitcoin" style="height: 25px;"> Bitcoin</h3>
                    <div class="payment-info" id="btc-info">
                        1DenPrDp1ACKnaBcFsRW1c9Kuvgv1mXiZh
                        <button class="copy-btn" onclick="copyToClipboard('btc-info', event)">Copiar</button>
                    </div>
                    <p id="btcDesc">Pagamento com criptomoedas</p>
                </div>
                
                <p id="modalFooter" style="text-align: center; margin-top: 30px;">Após o pagamento, envie o comprovante para nosso WhatsApp</p>
            </div>
        </div>

        <form method="GET" action="" id="search-form" class="search-form">
            <input type="text" id="search" name="search" placeholder="Digite o hash do arquivo ou categoria" required>
            <button type="submit" id="searchButton">Pesquisar</button>
        </form>

        <h2 id="uploadTitle">Enviar Arquivo</h2>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); if(isset($_GET['reply'])){echo "?reply=" . $_GET['reply'];} ?>" method="post" enctype="multipart/form-data" class="upload-form">
            <label for="uploaded_file" id="fileLabel">Selecione o arquivo:</label>
            <input type="file" name="uploaded_file" id="uploaded_file">

            <label for="text_content" id="textLabel">Ou digite o conteúdo:</label>
            <input type="text" name="text_content" id="text_content">

            <label for="category" id="categoryLabel">Categoria:</label>
            <input type="text" name="category" id="category" value="<?php if(isset($_GET['reply'])){echo $_GET['reply'];} ?>" required <?php if(isset($_GET['reply'])){echo "readonly";} ?>>

            <a id="more-options-link" class="more-options-link">Mais opções</a>
            
            <div id="optional-fields" class="optional-fields">
                <label for="btc" id="btcLabel">BTC/PIX (opcional):</label>
                <input type="text" name="btc" id="btc" placeholder="Endereço BTC">

                <label for="user" id="userLabel">Usuário (opcional):</label>
                <input type="text" name="user" id="user" placeholder="Nome de usuário">

                <label for="title" id="titleLabel">Título (opcional):</label>
                <input type="text" name="title" id="title" placeholder="Título do conteúdo">

                <label for="description" id="descLabel">Descrição (opcional):</label>
                <input type="text" name="description" id="description" placeholder="Descrição do conteúdo">

                <label for="url" id="urlLabel">URL da imagem (opcional):</label>
                <input type="url" name="url" id="url" placeholder="URL da miniatura">
            </div>
            <input type="submit" id="submitButton" value="Enviar">
        </form>

        <div class="footer-links">
            <a href="about.html" id="aboutLink">Sobre</a>
            <a href="add_server.php" id="serverLink">Adicionar servidor</a>
            <a href="downloader.php" id="downloaderLink">Downloader</a>
            <a href="blockchain.php" id="blockchainLink">Blockchain</a>  
            <a href="rank.php" id="rankLink">Ranking</a>   
        </div>
        <div class="copyright" id="copyrightText">Todos os direitos reservados</div>
    </div>

    <script>
        // Estado inicial
        let currentLanguage = 'pt';
        const languageButton = document.getElementById('languageButton');
        
        // Elementos que precisam de tradução
        const elementsToTranslate = {
            heading: document.querySelector('.main-heading'),
            subHeading: document.querySelector('.sub-heading'),
            pricingLink: document.getElementById('pricingLink'),
            contactButton: document.querySelector('.contact-button'),
            searchInput: document.querySelector('#search-form input'),
            searchButton: document.getElementById('searchButton'),
            uploadTitle: document.getElementById('uploadTitle'),
            fileLabel: document.getElementById('fileLabel'),
            textLabel: document.getElementById('textLabel'),
            categoryLabel: document.getElementById('categoryLabel'),
            optionsLink: document.getElementById('more-options-link'),
            btcLabel: document.getElementById('btcLabel'),
            userLabel: document.getElementById('userLabel'),
            titleLabel: document.getElementById('titleLabel'),
            descLabel: document.getElementById('descLabel'),
            urlLabel: document.getElementById('urlLabel'),
            submitButton: document.getElementById('submitButton'),
            aboutLink: document.getElementById('aboutLink'),
            serverLink: document.getElementById('serverLink'),
            downloaderLink: document.getElementById('downloaderLink'),
            blockchainLink: document.getElementById('blockchainLink'),
            rankLink: document.getElementById('rankLink'),
            copyrightText: document.getElementById('copyrightText'),
            // Modal elements
            modalTitle: document.getElementById('modalTitle'),
            pixDesc: document.getElementById('pixDesc'),
            paypalLink: document.getElementById('paypalLink'),
            paypalDesc: document.getElementById('paypalDesc'),
            btcDesc: document.getElementById('btcDesc'),
            modalFooter: document.getElementById('modalFooter')
        };

        // Traduções
        const translations = {
            pt: {
                heading: 'Ganhe dinheiro compartilhando arquivos',
                subHeading: 'Quanto mais likes e comentários você receber maiores são as suas recompensas. <span id="pricingLink" class="pricing-link">Adquira a sua conta por apenas 25,00 R$</span>',
                contactButton: 'Contato',
                languageButton: 'English',
                searchPlaceholder: 'Digite o hash do arquivo ou categoria',
                searchButton: 'Pesquisar',
                uploadTitle: 'Enviar Arquivo',
                fileLabel: 'Selecione o arquivo:',
                textLabel: 'Ou link:',
                categoryLabel: 'Categoria:',
                optionsLink: 'Mais opções',
                btcLabel: 'BTC/PIX (opcional):',
                userLabel: 'Usuário (opcional):',
                titleLabel: 'Título (opcional):',
                descLabel: 'Descrição (opcional):',
                urlLabel: 'URL da imagem (opcional):',
                submitButton: 'Enviar',
                aboutLink: 'Sobre',
                serverLink: 'Adicionar servidor',
                downloaderLink: 'Downloader',
                blockchainLink: 'Blockchain',
                rankLink: 'Ranking',
                copyrightText: 'Todos os direitos reservados',
                // Modal translations
                modalTitle: 'Escolha sua forma de pagamento',
                pixDesc: 'Pagamento instantâneo e sem taxas',
                paypalLink: 'Pagar via PayPal',
                paypalDesc: 'Pagamento internacional com cartão',
                btcDesc: 'Pagamento com criptomoedas',
                modalFooter: 'Após o pagamento, envie o comprovante para nosso WhatsApp'
            },
            en: {
                heading: 'Make money by sharing files',
                subHeading: 'The more likes and comments you receive, the higher your rewards. <span id="pricingLink" class="pricing-link">Premium account for only $5.00</span>',
                contactButton: 'Contact',
                languageButton: 'Português',
                searchPlaceholder: 'Enter file hash or category',
                searchButton: 'Search',
                uploadTitle: 'Upload File',
                fileLabel: 'Select File:',
                textLabel: 'Or link:',
                categoryLabel: 'Category:',
                optionsLink: 'More options',
                btcLabel: 'BTC/PIX (optional):',
                userLabel: 'User (optional):',
                titleLabel: 'Title (optional):',
                descLabel: 'Description (optional):',
                urlLabel: 'Image URL (optional):',
                submitButton: 'Upload',
                aboutLink: 'About',
                serverLink: 'Add server',
                downloaderLink: 'Downloader',
                blockchainLink: 'Blockchain',
                rankLink: 'Rank',
                copyrightText: 'All rights reserved',
                // Modal translations
                modalTitle: 'Choose your payment method',
                pixDesc: 'Instant payment with no fees',
                paypalLink: 'Pay via PayPal',
                paypalDesc: 'International payment with card',
                btcDesc: 'Cryptocurrency payment',
                modalFooter: 'After payment, send the receipt to our WhatsApp'
            }
        };

        // Função para aplicar as traduções
        function applyTranslations(lang) {
            const translation = translations[lang];
            
            // Atualizar todos os elementos
            for (const [key, element] of Object.entries(elementsToTranslate)) {
                if (element) {
                    if (key === 'subHeading' || key === 'pricingLink') {
                        element.innerHTML = translation[key];
                    } else {
                        element.textContent = translation[key];
                    }
                }
            }
            
            // Atualizar placeholder do input de busca
            document.querySelector('#search-form input').placeholder = translation.searchPlaceholder;
            
            // Reatribuir o event listener para o pricingLink
            const pricingLink = document.getElementById('pricingLink');
            if (pricingLink) {
                pricingLink.onclick = openModal;
            }
            
            // Atualizar o texto do link PayPal
            const paypalLink = document.getElementById('paypalLink');
            if (paypalLink) {
                paypalLink.textContent = translation.paypalLink;
            }
        }

        // Função para alternar idioma
        function toggleLanguage() {
            currentLanguage = currentLanguage === 'pt' ? 'en' : 'pt';
            applyTranslations(currentLanguage);
        }

        // Modal Functions
        function openModal() {
            document.getElementById('paymentModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('paymentModal').style.display = 'none';
        }

        function selectPayment(method) {
            console.log('Método selecionado:', method);
            // Aqui você pode adicionar lógica adicional quando um método é selecionado
        }

        function copyToClipboard(elementId, event) {
            event.stopPropagation();
            const element = document.getElementById(elementId);
            const text = element.innerText.replace('Copiar', '').replace('Copy', '').trim();
            
            navigator.clipboard.writeText(text).then(() => {
                const btn = event.target;
                btn.textContent = currentLanguage === 'pt' ? 'Copiado!' : 'Copied!';
                setTimeout(() => {
                    btn.textContent = currentLanguage === 'pt' ? 'Copiar' : 'Copy';
                }, 2000);
            });
        }

        // Fechar o modal se clicar fora dele
        window.onclick = function(event) {
            const modal = document.getElementById('paymentModal');
            if (event.target == modal) {
                closeModal();
            }
        }

        // Inicialização
        document.addEventListener('DOMContentLoaded', () => {
            // Configurar o botão de idioma
            languageButton.onclick = toggleLanguage;
            
            // Configurar o link de preço
            const pricingLink = document.getElementById('pricingLink');
            if (pricingLink) {
                pricingLink.onclick = openModal;
            }
            
            // Configurar o link de mais opções
            const moreOptionsLink = document.getElementById('more-options-link');
            const optionalFields = document.getElementById('optional-fields');
            
            if (moreOptionsLink && optionalFields) {
                moreOptionsLink.addEventListener('click', () => {
                    const isHidden = optionalFields.style.display === 'none' || optionalFields.style.display === '';
                    optionalFields.style.display = isHidden ? 'block' : 'none';
                    moreOptionsLink.textContent = isHidden ? 
                        (currentLanguage === 'pt' ? 'Menos opções' : 'Less options') : 
                        (currentLanguage === 'pt' ? 'Mais opções' : 'More options');
                });
            }
            
            // Aplicar traduções iniciais
            applyTranslations(currentLanguage);
        });
    </script>
</body>
</html>