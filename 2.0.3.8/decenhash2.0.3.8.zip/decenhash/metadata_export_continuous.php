<?php
// Define the directory to scan
$directory = 'files';

// Check if directory exists
if (!is_dir($directory)) {
    die("Error: Directory '$directory' does not exist.");
}

// Configuration
$maxEntriesPerFile = 20;
$maxFileSizeKB = 20;

// Define file type categories
$fileCategories = [
    'image' => ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'],
    'music' => ['mp3', 'wav', 'ogg', 'flac', 'aac'],
    'video' => ['mp4', 'mov', 'avi', 'mkv', 'flv', 'webm'],
    'pdf' => ['pdf'],
    'zip' => ['zip', 'rar', '7z', 'tar', 'gz'],
    'other' => [] // Default category
];

// Initialize an array to hold files grouped by category
$filesByCategory = [];

// Scan the directory
$files = scandir($directory);

foreach ($files as $file) {
    // Skip current and parent directory entries
    if ($file === '.' || $file === '..') {
        continue;
    }
    
    $filePath = $directory . '/' . $file;
    
    // Skip directories (only process files)
    if (is_dir($filePath)) {
        continue;
    }
    
    // Skip JSON files to prevent processing our own output
    if (strtolower(pathinfo($filePath, PATHINFO_EXTENSION)) === 'json') {
        continue;
    }
    
    // Get file information
    $pathInfo = pathinfo($filePath);
    $extension = isset($pathInfo['extension']) ? strtolower($pathInfo['extension']) : 'none';
    
    // Determine the file category
    $category = 'other';
    foreach ($fileCategories as $cat => $extensions) {
        if (in_array($extension, $extensions)) {
            $category = $cat;
            break;
        }
    }
    
    // If no extension, use 'other' category
    if ($extension === 'none') {
        $category = 'other';
    }
    
    // Generate a simple hash of the file
    $fileHash = md5_file($filePath);
    
    // Create file metadata
    $fileData = [
        'filename' => $file,
        'user' => get_current_user(), // Current system user
        'date' => date('Y-m-d', filemtime($filePath)), // Last modified date
        'hash' => $fileHash,
        'extension' => $extension,
        'link' => "files/$file",
        'url' => "",
        'description' => "" // Empty description by default
    ];
    
    // Add to the appropriate category group
    if (!isset($filesByCategory[$category])) {
        $filesByCategory[$category] = [];
    }
    $filesByCategory[$category][] = $fileData;
}

// Function to get existing JSON data
function getExistingJsonData($filename) {
    if (file_exists($filename)) {
        $content = file_get_contents($filename);
        return json_decode($content, true);
    }
    return null;
}

// Function to save paginated JSON files
function savePaginatedJson($category, $files, $maxEntries, $maxSizeKB) {
    // First get all existing JSON files for this category
    $existingFiles = glob("{$category}*.json");
    $existingData = [];
    
    foreach ($existingFiles as $existingFile) {
        $data = getExistingJsonData($existingFile);
        if ($data && isset($data['files'])) {
            $existingData[$existingFile] = $data;
        }
    }
    
    // Process remaining files that haven't been added yet
    $remainingFiles = $files;
    
    // Remove files that already exist in any JSON file
    foreach ($existingData as $fileData) {
        foreach ($fileData['files'] as $existingEntry) {
            $remainingFiles = array_filter($remainingFiles, function($file) use ($existingEntry) {
                return $file['hash'] !== $existingEntry['hash'];
            });
        }
    }
    
    // Re-index array after filtering
    $remainingFiles = array_values($remainingFiles);
    
    // If no remaining files, just return
    if (empty($remainingFiles)) {
        echo "No new files to add for category: $category\n";
        return;
    }
    
    // Try to add remaining files to existing JSON files that have space
    foreach ($existingData as $filename => &$data) {
        if (count($data['files']) >= $maxEntries) {
            continue; // Skip files that already have max entries
        }
        
        $currentSizeKB = strlen(json_encode($data)) / 1024;
        if ($currentSizeKB >= $maxSizeKB) {
            continue; // Skip files that are already at max size
        }
        
        // Calculate how much space we have left
        $remainingSpaceKB = $maxSizeKB - $currentSizeKB;
        $addedCount = 0;
        
        foreach ($remainingFiles as $key => $file) {
            $fileSizeKB = strlen(json_encode($file)) / 1024;
            
            if ($fileSizeKB <= $remainingSpaceKB && count($data['files']) < $maxEntries) {
                $data['files'][] = $file;
                $remainingSpaceKB -= $fileSizeKB;
                unset($remainingFiles[$key]);
                $addedCount++;
            }
            
            if ($remainingSpaceKB <= 0 || count($data['files']) >= $maxEntries) {
                break;
            }
        }
        
        if ($addedCount > 0) {
            // Update metadata
            $data['metadata']['total_files'] += $addedCount;
            $data['metadata']['chunk_size'] = count($data['files']);
            $data['metadata']['chunk_size_kb'] = round(strlen(json_encode($data)) / 1024, 2);
            
            // Save updated file
            file_put_contents('data_json/' . $filename, json_encode($data, JSON_PRETTY_PRINT));
            echo "Updated JSON file: $filename - added $addedCount entries (now " . 
                 count($data['files']) . " entries, " . 
                 round(strlen(json_encode($data)) / 1024, 2) . " KB)\n";
        }
    }
    
    // Re-index remaining files array
    $remainingFiles = array_values($remainingFiles);
    
    // If we still have remaining files, create new JSON files for them
    if (!empty($remainingFiles)) {
        $chunks = [];
        $currentChunk = [];
        $currentSize = 0;
        
        foreach ($remainingFiles as $file) {
            $fileSize = strlen(json_encode($file));
            
            // Check if adding this file would exceed limits
            if (count($currentChunk) >= $maxEntries || 
                ($currentSize + $fileSize) > ($maxSizeKB * 1024)) {
                // Save current chunk and start new one
                $chunks[] = $currentChunk;
                $currentChunk = [];
                $currentSize = 0;
            }
            
            $currentChunk[] = $file;
            $currentSize += $fileSize;
        }
        
        // Add the last chunk if not empty
        if (!empty($currentChunk)) {
            $chunks[] = $currentChunk;
        }
        
        // Determine starting file number for new chunks
        $maxFileNumber = 0;
        foreach ($existingFiles as $existingFile) {
            if (preg_match("/{$category}_(\d+)\.json/", $existingFile, $matches)) {
                $maxFileNumber = max($maxFileNumber, (int)$matches[1]);
            }
        }
        $startFileNumber = $maxFileNumber + 1;
        
        // Save each chunk to separate file
        foreach ($chunks as $index => $chunk) {
            $fileNumber = $startFileNumber + $index;
            $jsonFileName = ($fileNumber === 1) ? "$category.json" : "{$category}_{$fileNumber}.json";
            
            $jsonData = [
                'files' => $chunk,
                'metadata' => [
                    'total_files' => count($remainingFiles),
                    'current_chunk' => $fileNumber,
                    'total_chunks' => count($chunks),
                    'chunk_size' => count($chunk),
                    'chunk_size_kb' => round(strlen(json_encode($chunk)) / 1024, 2)
                ]
            ];
            
            file_put_contents('data_json/' . $jsonFileName, json_encode($jsonData, JSON_PRETTY_PRINT));
            echo "Created new JSON file: $jsonFileName with " . count($chunk) . " entries (" . 
                 round(strlen(json_encode($jsonData)) / 1024, 2) . " KB).\n";
        }
    }
}

// Process each category
foreach ($filesByCategory as $category => $files) {
    savePaginatedJson($category, $files, $maxEntriesPerFile, $maxFileSizeKB);
}

echo "Processing complete.\n";
?>