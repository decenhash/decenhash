<?php
// Function to get all MP3 files from the 'musics' folder
function getMusicFiles() {
    $musicPath = 'musics/';
    $files = [];
    
    // Check if directory exists
    if (!is_dir($musicPath)) {
        mkdir($musicPath, 0755, true);
        echo "Created 'musics' directory as it didn't exist.<br>";
        return $files;
    }
    
    // Get all MP3 files
    $allFiles = scandir($musicPath);
    foreach ($allFiles as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'mp3') {
            $files[] = $file;
        }
    }
    
    return $files;
}

// Function to get thumbnail for a music file
function getThumbnail($filename) {
    // Extract the part before the hyphen
    $parts = explode('-', $filename);
    if (count($parts) > 0) {
        $artist = $parts[0];
        $thumbnailPath = 'musics/' . $artist . '.jpg';
        
        // Check if thumbnail exists
        if (file_exists($thumbnailPath)) {
            return $thumbnailPath;
        }
    }
    
    // Return a default thumbnail if specific one doesn't exist
    return 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/svgs/solid/music.svg';
}

// Function to get song title from filename
function getSongTitle($filename) {
    $parts = explode('-', $filename);
    if (count($parts) > 1) {
        return pathinfo($parts[1], PATHINFO_FILENAME);
    }
    return pathinfo($filename, PATHINFO_FILENAME);
}

// Function to get artist name from filename
function getArtistName($filename) {
    $parts = explode('-', $filename);
    if (count($parts) > 0) {
        return $parts[0];
    }
    return "Unknown Artist";
}

// Get all music files
$musicFiles = getMusicFiles();

// Prepare the JSON array
$musicData = [];

foreach ($musicFiles as $index => $file) {
    $musicData[] = [
        'id' => $index,
        'filename' => $file,
        'filePath' => 'musics/' . $file,
        'title' => getSongTitle($file),
        'artist' => getArtistName($file),
        'thumbPath' => getThumbnail($file)
    ];
}

// Generate the JSON file
$jsonContent = json_encode($musicData, JSON_PRETTY_PRINT);
file_put_contents('data_json/data.json', $jsonContent);

echo "Music JSON file generated successfully!<br>";
echo "Found " . count($musicFiles) . " MP3 files.<br>";

// Display the JSON content for debugging
echo "<h3>JSON Content:</h3>";
echo "<pre>" . htmlspecialchars($jsonContent) . "</pre>";
?>