﻿<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hash Redirect</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        }
        
        body {
            background: #f8f9fa;
            color: #212529;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            line-height: 1.5;
        }
        
        .container {
            width: 100%;
            max-width: 500px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 40px;
        }
        
        h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 8px;
            color: #1a1a1a;
        }
        
        .subtitle {
            color: #6c757d;
            margin-bottom: 30px;
            font-size: 0.9rem;
        }
        
        .message {
            padding: 16px;
            border-radius: 6px;
            margin-bottom: 24px;
            border-left: 4px solid;
        }
        
        .success {
            background: #f8fff8;
            border-color: #28a745;
            color: #155724;
        }
        
        .error {
            background: #fff8f8;
            border-color: #dc3545;
            color: #721c24;
        }
        
        .info {
            background: #f8fdff;
            border-color: #17a2b8;
            color: #0c5460;
        }
        
        .redirect-info {
            background: #f8f9fa;
            padding: 16px;
            border-radius: 6px;
            margin: 20px 0;
            font-size: 0.9rem;
        }
        
        .link {
            display: block;
            padding: 12px 16px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            text-align: center;
            margin: 20px 0;
            transition: background 0.2s;
        }
        
        .link:hover {
            background: #0056b3;
        }
        
        .countdown {
            text-align: center;
            margin: 20px 0;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .data-item {
            display: flex;
            margin-bottom: 8px;
            font-size: 0.9rem;
        }
        
        .data-label {
            font-weight: 500;
            width: 80px;
            color: #495057;
        }
        
        .form-group {
            margin-top: 30px;
        }
        
        input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            font-size: 14px;
            margin-bottom: 12px;
        }
        
        input:focus {
            outline: none;
            border-color: #007bff;
        }
        
        button {
            width: 100%;
            padding: 12px 16px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.2s;
        }
        
        button:hover {
            background: #218838;
        }
        
        footer {
            text-align: center;
            margin-top: 30px;
            color: #6c757d;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        include("click_counter.php"); 

        // Create directories if they don't exist
        if (!is_dir("json")) mkdir("json", 0777, true);
        if (!is_dir("files")) mkdir("files", 0777, true);
        
        // Initialize variables
        $hash = $_GET['hash'] ?? '';
        $jsonFile = '';
        $data = null;
        $message = '';
        $messageType = 'info';
        $redirectUrl = '';
        
        if (!empty($hash)) {
            // Clean the hash
            $hash = preg_replace('/[^a-zA-Z0-9]/', '', $hash);
            $jsonFile = "json/" . $hash . ".json";
            
            if (file_exists($jsonFile)) {
                $jsonContent = file_get_contents($jsonFile);
                $data = json_decode($jsonContent, true);
                
                if ($data) {
                    if (!empty($data['size']) && !empty($data['type'])) {
                        $redirectUrl = "files/" . $hash . "." . $data['type'];
                    } else {
                        $redirectUrl = $data['url'] ?? '';
                    }
                    
                    if (!empty($redirectUrl)) {
                        $message = "Redirecionando em 3 segundos...";
                        $messageType = 'success';
                    } else {
                        $message = "Arquivo encontrado, mas sem URL para redirecionamento";
                        $messageType = 'error';
                    }
                } else {
                    $message = "Erro ao ler arquivo JSON";
                    $messageType = 'error';
                }
            } else {
                $message = "Hash não encontrado: " . htmlspecialchars($hash);
                $messageType = 'error';
            }
        } else {
            $message = "Digite um hash para verificar";
            $messageType = 'info';
        }
        ?>
        
        <h1>Hash Redirect</h1>
        <p class="subtitle">Verificação e redirecionamento por hash</p>
        
        <div class="message <?php echo $messageType; ?>">
            <?php echo $message; ?>
        </div>
        
        <?php if (!empty($redirectUrl)): ?>
            <div class="redirect-info">
                Destino: <?php echo htmlspecialchars($redirectUrl); ?>
            </div>
            
            <a href="<?php echo htmlspecialchars($redirectUrl); ?>" class="link">
                Acessar agora
            </a>
            
            <div class="countdown" id="countdown">
                Redirecionando em <span id="count">3</span>s
            </div>
            
            <?php if ($data): ?>
                <div style="margin-top: 20px;">
                    <?php foreach ($data as $key => $value): ?>
                        <div class="data-item">
                            <div class="data-label"><?php echo htmlspecialchars($key); ?>:</div>
                            <div><?php echo htmlspecialchars($value); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <script>
                let count = 3;
                const countElement = document.getElementById('count');
                const redirectUrl = "<?php echo $redirectUrl; ?>";
                
                const countdown = setInterval(() => {
                    count--;
                    countElement.textContent = count;
                    if (count <= 0) {
                        clearInterval(countdown);
                        window.location.href = redirectUrl;
                    }
                }, 1000);
            </script>
        <?php endif; ?>
        
        <div class="form-group">
            <input 
                type="text" 
                name="hash" 
                placeholder="Digite o hash"
                value="<?php echo htmlspecialchars($hash); ?>"
                onkeypress="if(event.key=='Enter') document.getElementById('checkBtn').click()"
            >
            <button id="checkBtn" onclick="checkHash()">
                Verificar Hash
            </button>
        </div>
        
        <footer>
            &copy; <?php echo date('Y'); ?> Hash Redirect System
        </footer>
    </div>

    <script>
        function checkHash() {
            const hash = document.querySelector('input[name="hash"]').value.trim();
            if (hash) {
                window.location.href = '?hash=' + encodeURIComponent(hash);
            }
        }
        
        // Focus on input field
        document.querySelector('input[name="hash"]').focus();
    </script>
</body>
</html>