<?php
// Start session to access session variables
session_start();

// Define the path to the JSON file
$groupsFile = 'groups.json';

// Initialize variables
$formData = [
    'title' => '',
    'category' => '',
    'platform' => 'WhatsApp',
    'description' => '',
    'language' => 'English',
    'created' => date('F j, Y'),
    'link' => '',
    'rules' => [],
    'user' => isset($_SESSION['user']) ? $_SESSION['user'] : ''
];
$errors = [];
$success = false;

// Load existing groups if file exists
$existingGroups = [];
if (file_exists($groupsFile)) {
    $existingGroups = json_decode(file_get_contents($groupsFile), true);
    if ($existingGroups === null) {
        $existingGroups = [];
    }
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input
    $formData['title'] = trim($_POST['title'] ?? '');
    $formData['category'] = trim($_POST['category'] ?? '');
    $formData['platform'] = trim($_POST['platform'] ?? 'WhatsApp');
    $formData['description'] = trim($_POST['description'] ?? '');
    $formData['language'] = trim($_POST['language'] ?? 'English');
    $formData['created'] = trim($_POST['created'] ?? date('F j, Y'));
    $formData['link'] = trim($_POST['link'] ?? '');
    $formData['user'] = isset($_SESSION['user']) ? $_SESSION['user'] : '';
    
    // Process rules (split by newline)
    $rulesText = trim($_POST['rules'] ?? '');
    $formData['rules'] = array_filter(array_map('trim', explode("\n", $rulesText)));

    // Validate required fields
    if (empty($formData['title'])) {
        $errors['title'] = 'Group title is required';
    }
    if (empty($formData['category'])) {
        $errors['category'] = 'Category is required';
    }
    if (empty($formData['description'])) {
        $errors['description'] = 'Description is required';
    }
    if (empty($formData['link'])) {
        $errors['link'] = 'Group link is required';
    }
    if (empty($formData['rules'])) {
        $errors['rules'] = 'At least one group rule is required';
    }

    // If no errors, save to JSON file
    if (empty($errors)) {
        // Add the new group to existing groups
        $existingGroups[] = $formData;
        
        // Save to JSON file
        if (file_put_contents($groupsFile, json_encode($existingGroups, JSON_PRETTY_PRINT))) {
            $success = true;
            // Reset form data for new entry
            $formData = [
                'title' => '',
                'category' => '',
                'platform' => 'WhatsApp',
                'description' => '',
                'language' => 'English',
                'created' => date('F j, Y'),
                'link' => '',
                'rules' => [],
                'user' => isset($_SESSION['user']) ? $_SESSION['user'] : ''
            ];
        } else {
            $errors['save'] = 'Failed to save group data. Please check file permissions.';
        }
    }
}

// Get unique categories for suggestions
$uniqueCategories = [];
foreach ($existingGroups as $group) {
    if (!in_array($group['category'], $uniqueCategories)) {
        $uniqueCategories[] = $group['category'];
    }
}
sort($uniqueCategories);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Group</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        input[type="text"],
        input[type="url"],
        select,
        textarea {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .error {
            color: #e74c3c;
            font-size: 14px;
            margin-top: 5px;
        }
        
        .success {
            color: #27ae60;
            background-color: #e8f8f0;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        button {
            background-color: #25D366;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        
        button:hover {
            background-color: #1da851;
        }
        
        .datalist-options {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add New Messaging Group</h1>
        
        <?php if ($success): ?>
            <div class="success">
                Group has been successfully added! <a href="groups.html">View all groups</a>
            </div>
        <?php endif; ?>
        
        <?php if (isset($errors['save'])): ?>
            <div class="error"><?= htmlspecialchars($errors['save']) ?></div>
        <?php endif; ?>
        
        <form method="post">
            <div class="form-group">
                <label for="title">Group Title*</label>
                <input type="text" id="title" name="title" value="<?= htmlspecialchars($formData['title']) ?>" required>
                <?php if (isset($errors['title'])): ?>
                    <div class="error"><?= htmlspecialchars($errors['title']) ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="category">Category*</label>
                <input type="text" id="category" name="category" list="categories" value="<?= htmlspecialchars($formData['category']) ?>" required>
                <datalist id="categories">
                    <?php foreach ($uniqueCategories as $category): ?>
                        <option value="<?= htmlspecialchars($category) ?>">
                    <?php endforeach; ?>
                </datalist>
                <div class="datalist-options">Existing categories: <?= implode(', ', $uniqueCategories) ?></div>
                <?php if (isset($errors['category'])): ?>
                    <div class="error"><?= htmlspecialchars($errors['category']) ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="platform">Platform*</label>
                <select id="platform" name="platform" required>
                    <option value="WhatsApp" <?= $formData['platform'] === 'WhatsApp' ? 'selected' : '' ?>>WhatsApp</option>
                    <option value="Telegram" <?= $formData['platform'] === 'Telegram' ? 'selected' : '' ?>>Telegram</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="description">Description*</label>
                <textarea id="description" name="description" required><?= htmlspecialchars($formData['description']) ?></textarea>
                <?php if (isset($errors['description'])): ?>
                    <div class="error"><?= htmlspecialchars($errors['description']) ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="language">Language</label>
                <input type="text" id="language" name="language" value="<?= htmlspecialchars($formData['language']) ?>">
            </div>
            
            <div class="form-group">
                <label for="created">Created Date</label>
                <input type="text" id="created" name="created" value="<?= htmlspecialchars($formData['created']) ?>">
            </div>
            
            <div class="form-group">
                <label for="link">Group Link*</label>
                <input type="url" id="link" name="link" value="<?= htmlspecialchars($formData['link']) ?>" required>
                <?php if (isset($errors['link'])): ?>
                    <div class="error"><?= htmlspecialchars($errors['link']) ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="rules">Group Rules (one per line)*</label>
                <textarea id="rules" name="rules" required><?= htmlspecialchars(implode("\n", $formData['rules'])) ?></textarea>
                <?php if (isset($errors['rules'])): ?>
                    <div class="error"><?= htmlspecialchars($errors['rules']) ?></div>
                <?php endif; ?>
            </div>
            
            <button type="submit">Add Group</button>
        </form>
    </div>
</body>
</html>