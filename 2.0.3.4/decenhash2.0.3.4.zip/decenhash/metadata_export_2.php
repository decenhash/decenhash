<?php
// Define the directory to scan
$directory = 'files';

// Check if directory exists
if (!is_dir($directory)) {
    die("Error: Directory '$directory' does not exist.");
}

// Define file type categories
$fileCategories = [
    'image' => ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'],
    'music' => ['mp3', 'wav', 'ogg', 'flac', 'aac'],
    'video' => ['mp4', 'mov', 'avi', 'mkv', 'flv', 'webm'],
    'pdf' => ['pdf'],
    'zip' => ['zip', 'rar', '7z', 'tar', 'gz'],
    'other' => [] // Default category
];

// Initialize an array to hold files grouped by category
$filesByCategory = [];

// Scan the directory
$files = scandir($directory);

foreach ($files as $file) {
    // Skip current and parent directory entries
    if ($file === '.' || $file === '..') {
        continue;
    }
    
    $filePath = $directory . '/' . $file;
    
    // Skip directories (only process files)
    if (is_dir($filePath)) {
        continue;
    }
    
    // Get file information
    $pathInfo = pathinfo($filePath);
    $extension = isset($pathInfo['extension']) ? strtolower($pathInfo['extension']) : 'none';
    
    // Determine the file category
    $category = 'other';
    foreach ($fileCategories as $cat => $extensions) {
        if (in_array($extension, $extensions)) {
            $category = $cat;
            break;
        }
    }
    
    // If no extension, use 'other' category
    if ($extension === 'none') {
        $category = 'other';
    }
    
    // Generate a simple hash of the file
    $fileHash = md5_file($filePath);
    
    // Create file metadata
    $fileData = [
        'filename' => $file,
        'user' => get_current_user(), // Current system user
        'date' => date('Y-m-d', filemtime($filePath)), // Last modified date
        'hash' => $fileHash,
        'extension' => $extension,
        'link' => "files/$file",
        'url' => "",
        'description' => "" // Empty description by default
    ];
    
    // Add to the appropriate category group
    if (!isset($filesByCategory[$category])) {
        $filesByCategory[$category] = [];
    }
    $filesByCategory[$category][] = $fileData;
}

// Create JSON files for each category
foreach ($filesByCategory as $category => $files) {
    $jsonData = [
        'files' => $files
    ];
    
    $jsonFileName = $category . '.json';
    
    // Write JSON to file
    file_put_contents('data_json/' . $jsonFileName, json_encode($jsonData, JSON_PRETTY_PRINT));
    
    echo "Created JSON file: $jsonFileName with " . count($files) . " entries.\n";
}

echo "Processing complete.\n";
?>