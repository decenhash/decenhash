<?php
// Handle language selection
session_start();
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}

// Set default language to English if not set
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en';
}

// Language strings
$lang = [
    'en' => [
        'title' => 'Submit AI Service',
        'success' => 'Service submitted successfully!',
        'error' => 'Error saving service. Please try again.',
        'required_fields' => 'Please fill in all required fields.',
        'service_title' => 'Service Title*',
        'provider_name' => 'Provider Name*',
        'categories' => 'Categories* (comma separated)',
        'categories_hint' => 'Example: music, code, picture, text, speech, video, art, business',
        'thumbnail_url' => 'Thumbnail URL',
        'description' => 'Description*',
        'price' => 'Price*',
        'contact_email' => 'Contact Email*',
        'submit' => 'Submit Service',
        'back' => '? Back to Marketplace',
        'switch_pt' => 'Portugu�s',
        'switch_en' => 'English'
    ],
    'pt' => [
        'title' => 'Enviar Servi�o de IA',
        'success' => 'Servi�o enviado com sucesso!',
        'error' => 'Erro ao salvar servi�o. Por favor, tente novamente.',
        'required_fields' => 'Por favor, preencha todos os campos obrigat�rios.',
        'service_title' => 'T�tulo do Servi�o*',
        'provider_name' => 'Nome do Provedor*',
        'categories' => 'Categorias* (separadas por v�rgula)',
        'categories_hint' => 'Exemplo: m�sica, c�digo, imagem, texto, fala, v�deo, arte, neg�cios',
        'thumbnail_url' => 'URL da Miniatura',
        'description' => 'Descri��o*',
        'price' => 'Pre�o*',
        'contact_email' => 'Email de Contato*',
        'submit' => 'Enviar Servi�o',
        'back' => '? Voltar para o Marketplace',
        'switch_pt' => 'Portugu�s',
        'switch_en' => 'Ingl�s'
    ]
];

$currentLang = $_SESSION['lang'];
$t = $lang[$currentLang];

// Create market directory if it doesn't exist
if (!file_exists('market')) {
    mkdir('market', 0755, true);
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $service = [
        'title' => filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING),
        'provider' => filter_input(INPUT_POST, 'provider', FILTER_SANITIZE_STRING),
        'categories' => isset($_POST['categories']) ? array_map('trim', explode(',', $_POST['categories'])) : [],
        'thumb' => filter_input(INPUT_POST, 'thumb', FILTER_SANITIZE_URL),
        'description' => filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING),
        'price' => filter_input(INPUT_POST, 'price', FILTER_SANITIZE_STRING),
        'contact' => filter_input(INPUT_POST, 'contact', FILTER_SANITIZE_EMAIL)
    ];

    // Validate required fields
    if (empty($service['title']) || empty($service['provider']) || empty($service['description']) || 
        empty($service['price']) || empty($service['contact']) || empty($service['categories'])) {
        $error = $t['required_fields'];
    } else {
        // Generate filename based on content hash
        $jsonContent = json_encode($service, JSON_PRETTY_PRINT);
        $filename = hash('sha256', $jsonContent) . '.json';
        $filepath = 'market/' . $filename;

        // Save to file
        if (file_put_contents($filepath, $jsonContent)) {
            $success = $t['success'];
            // Clear form
            $service = array_fill_keys(array_keys($service), '');
        } else {
            $error = $t['error'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $t['title']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        
        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="url"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .categories-hint {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }
        
        .submit-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: #1DB954;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .submit-btn:hover {
            background-color: #19a64b;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #1DB954;
            text-decoration: none;
            font-weight: 500;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        .language-switcher {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        
        .language-btn {
            background: none;
            border: 1px solid #1DB954;
            color: #1DB954;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 5px;
            transition: all 0.3s ease;
        }
        
        .language-btn:hover {
            background-color: #1DB954;
            color: white;
        }
        
        .language-btn.active {
            background-color: #1DB954;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="language-switcher">
            <a href="?lang=en" class="language-btn <?php echo $currentLang === 'en' ? 'active' : ''; ?>"><?php echo $t['switch_en']; ?></a>
            <a href="?lang=pt" class="language-btn <?php echo $currentLang === 'pt' ? 'active' : ''; ?>"><?php echo $t['switch_pt']; ?></a>
        </div>
        
        <h1><?php echo $t['title']; ?></h1>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="title"><?php echo $t['service_title']; ?></label>
                <input type="text" id="title" name="title" required 
                       value="<?php echo isset($service['title']) ? htmlspecialchars($service['title']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="provider"><?php echo $t['provider_name']; ?></label>
                <input type="text" id="provider" name="provider" required
                       value="<?php echo isset($service['provider']) ? htmlspecialchars($service['provider']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="categories"><?php echo $t['categories']; ?></label>
                <input type="text" id="categories" name="categories" required
                       value="<?php echo isset($service['categories']) ? htmlspecialchars(implode(', ', $service['categories'])) : ''; ?>">
                <p class="categories-hint"><?php echo $t['categories_hint']; ?></p>
            </div>
            
            <div class="form-group">
                <label for="thumb"><?php echo $t['thumbnail_url']; ?></label>
                <input type="url" id="thumb" name="thumb" 
                       value="<?php echo isset($service['thumb']) ? htmlspecialchars($service['thumb']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="description"><?php echo $t['description']; ?></label>
                <textarea id="description" name="description" required><?php 
                    echo isset($service['description']) ? htmlspecialchars($service['description']) : ''; 
                ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="price"><?php echo $t['price']; ?></label>
                <input type="text" id="price" name="price" required
                       value="<?php echo isset($service['price']) ? htmlspecialchars($service['price']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="contact"><?php echo $t['contact_email']; ?></label>
                <input type="email" id="contact" name="contact" required
                       value="<?php echo isset($service['contact']) ? htmlspecialchars($service['contact']) : ''; ?>">
            </div>
            
            <button type="submit" class="submit-btn"><?php echo $t['submit']; ?></button>
        </form>
        
        <a href="index.html" class="back-link"><?php echo $t['back']; ?></a>
    </div>
</body>
</html>