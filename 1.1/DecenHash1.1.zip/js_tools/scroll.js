// Get the current page number from the URL
function getCurrentPageNumber() {
    const currentPath = window.location.pathname;
    const match = currentPath.match(/index_(\d+)\.html$/);
    
    if (match) {
        return parseInt(match[1]);
    } else if (currentPath.endsWith('index.html') || currentPath === '/' || currentPath === '') {
        return 1;
    } else {
        return 1; // Default to page 1 if pattern not found
    }
}

// Navigate to the next page
function goToNextPage() {
    const currentPage = getCurrentPageNumber();
    const nextPage = currentPage + 1;
    const nextPageUrl = `index_${nextPage}.html`;
    
    // Add a small delay to make the transition feel more natural
    setTimeout(() => {
        window.location.href = nextPageUrl;
    }, 300);
}

// Update the page number display
function updatePageNumber() {
    const pageNumberElement = document.getElementById('pageNumber');
    pageNumberElement.textContent = `Page ${getCurrentPageNumber()}`;
}

// Set up event listeners
document.addEventListener('DOMContentLoaded', function() {
    updatePageNumber();
    
    // Scroll event for detecting when user reaches bottom of page
    let scrollTimeout;
    let hasTriggeredNavigation = false;
    
    window.addEventListener('scroll', function() {
        clearTimeout(scrollTimeout);
        
        scrollTimeout = setTimeout(function() {
            const scrollPosition = window.scrollY + window.innerHeight;
            const documentHeight = document.documentElement.scrollHeight;
            
            // If user has scrolled to bottom (with a small buffer)
            if (scrollPosition >= documentHeight - 50 && !hasTriggeredNavigation) {
                hasTriggeredNavigation = true;
                goToNextPage();
            }
        }, 200);
    });
    
    // Click event for the sphere button
    const nextButton = document.getElementById('nextButton');
    nextButton.addEventListener('click', function() {
        hasTriggeredNavigation = true;
        goToNextPage();
    });
});