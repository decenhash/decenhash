<?php
// Load the sitenames from the external PHP file
$sitename = ['upload','file-upload'];
// Array of TLDs
$tlds = require 'tlds.php';
// Directories for storing URLs
$directories = ['online' => 'online', 'offline' => 'offline'];

// Create directories if they don't exist
foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true); // Ensure permission and recursive creation
    }
}

// Database connection parameters
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'decenhash';

// Create MySQL connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create tables if they don't exist
$sql = "CREATE TABLE IF NOT EXISTS checked_urls (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    url VARCHAR(255) NOT NULL,
    status ENUM('online', 'offline') NOT NULL,
    check_date DATETIME NOT NULL,
    top_words TEXT,
    UNIQUE KEY (url)
)";

if (!$conn->query($sql)) {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Function to handle file creation
function saveToFile($filename) {
    $file = fopen($filename, 'w');
    if ($file) {
        fwrite($file, ""); // Empty content, just ensuring file creation
        fclose($file);
    } else {
        echo "Error: Unable to create file $filename.<br>";
    }
}

// Function to extract top words from a web page
function getTopWords($url) {
    // Get the content of the page
    $content = @file_get_contents($url);
    if (!$content) {
        return "";
    }
    
    // Remove HTML tags
    $text = strip_tags($content);
    
    // Remove special characters and convert to lowercase
    $text = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $text);
    $text = strtolower($text);
    
    // Split into words
    $words = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
    
    // Common HTML-related words to exclude
    $excludeWords = [
        'html', 'body', 'div', 'span', 'class', 'id', 'script', 'style',
        'head', 'meta', 'link', 'img', 'src', 'href', 'alt', 'title',
        'function', 'var', 'let', 'const', 'return', 'true', 'false',
        'null', 'undefined', 'the', 'and', 'for', 'this', 'that', 'width',
        'height', 'type', 'document', 'window', 'http', 'https', 'www'
    ];
    
    // Count word frequency, excluding common HTML words
    $wordCount = [];
    foreach ($words as $word) {
        if (strlen($word) > 2 && !in_array($word, $excludeWords)) {
            if (!isset($wordCount[$word])) {
                $wordCount[$word] = 0;
            }
            $wordCount[$word]++;
        }
    }
    
    // Sort by frequency
    arsort($wordCount);
    
    // Get top 10 words
    $topWords = array_slice($wordCount, 0, 10, true);
    
    // Format as JSON for storage
    return json_encode($topWords);
}

// Function to check if URL exists in database
function isUrlChecked($conn, $url) {
    $stmt = $conn->prepare("SELECT id FROM checked_urls WHERE url = ?");
    $stmt->bind_param("s", $url);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result->num_rows > 0;
    $stmt->close();
    return $exists;
}

// Iterate over sitenames and TLDs
foreach ($sitename as $name) {
    foreach ($tlds as $tld) {
        $url = 'http://' . $name . '.' . $tld;
        $filenameOnline = $directories['online'] . '/' . $name . '.' . $tld . '.txt';
        $filenameOffline = $directories['offline'] . '/' . $name . '.' . $tld . '.txt';
        
        // Skip if either online or offline file already exists
        if (file_exists($filenameOnline) || file_exists($filenameOffline)) {
            echo "Skipping $url (already checked)<br>";
            continue; // Skip to the next URL check
        }
        
        // Skip if URL already exists in database
        if (isUrlChecked($conn, $url)) {
            echo "Skipping $url (already in database)<br>";
            continue;
        }

        // Check if the URL is reachable
        $headers = @get_headers($url);
        $isOnline = $headers && strpos($headers[0], '200') !== false;
        
        // Determine status
        $status = $isOnline ? 'online' : 'offline';
        
        // Get top words for online sites
        $topWords = "";
        if ($isOnline) {
            $topWords = getTopWords($url);
            echo "$name.$tld is online<br>";
            saveToFile($filenameOnline);

        // Insert into database
        $stmt = $conn->prepare("INSERT INTO checked_urls (url, status, check_date, top_words) VALUES (?, ?, NOW(), ?)");
        $stmt->bind_param("sss", $url, $status, $topWords);
        
        if (!$stmt->execute()) {
            echo "Error: " . $stmt->error . "<br>";
        }
        $stmt->close();


        } else {
            echo "$name.$tld is offline or unreachable<br>";
            saveToFile($filenameOffline);
        }
        

        
        // Pause briefly to avoid overwhelming servers
        usleep(500000); // 0.5 seconds
    }
}

// Close database connection
$conn->close();

echo "URL check completed.";
?>