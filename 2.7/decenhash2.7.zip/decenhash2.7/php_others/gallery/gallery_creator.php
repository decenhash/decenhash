<?php
// Set the directories
$imagesDir = 'images';
$dataDir = 'data';

// Create data directory if it doesn't exist
if (!file_exists($dataDir)) {
    mkdir($dataDir, 0755, true);
}

// Get all subdirectories (categories)
$categories = array_filter(glob($imagesDir . '/*'), 'is_dir');

// Process each category
$allPhotos = [];
foreach ($categories as $categoryPath) {
    $categoryName = basename($categoryPath);
    $images = glob($categoryPath . '/*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
    
    $categoryPhotos = [];
    foreach ($images as $imagePath) {
        $filename = basename($imagePath);
        $photoData = [
            'title' => pathinfo($filename, PATHINFO_FILENAME),
            'category' => $categoryName,
            'thumb' => $imagePath,
            'fullSize' => $imagePath,
            'description' => 'Photo of ' . pathinfo($filename, PATHINFO_FILENAME)
        ];
        $categoryPhotos[] = $photoData;
        $allPhotos[] = $photoData;
    }
    
    // Save category JSON
    file_put_contents("$dataDir/$categoryName.json", json_encode($categoryPhotos, JSON_PRETTY_PRINT));
}

// Save all photos JSON
file_put_contents("$dataDir/all_photos.json", json_encode($allPhotos, JSON_PRETTY_PRINT));

echo "JSON files generated successfully!";
?>