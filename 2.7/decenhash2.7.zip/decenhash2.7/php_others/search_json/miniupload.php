﻿<?php
// Database and file handling
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "decenhash";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Create table if not exists
$sql = "CREATE TABLE IF NOT EXISTS works (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    file_hash VARCHAR(64) NOT NULL,
    file_extension VARCHAR(10) NOT NULL,
    date DATETIME NOT NULL,
    pix_key VARCHAR(255) NOT NULL,
    file_size VARCHAR(20) NOT NULL,
    points DECIMAL(10,2) NOT NULL,
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if (!$conn->query($sql) === TRUE) {
    echo "Erro criando tabela: " . $conn->error;
}

$message = '';
$uploadOk = 1;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if files were uploaded
    if (isset($_FILES["file_upload"])) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file = $_FILES["file_upload"];
        $thumbnail = $_FILES["thumbnail"];
        $pix_key = $_POST["pix_key"];
        $points = $_POST["points"];
        
        // Check file size
        if ($file["size"] > 10 * 1024 * 1024) {
            $message = "Desculpe, o arquivo é muito grande. Tamanho máximo permitido: 10MB.";
            $uploadOk = 0;
        }
        
        // Check file extension
        $file_ext = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
        $thumbnail_ext = strtolower(pathinfo($thumbnail["name"], PATHINFO_EXTENSION));
        
        if ($file_ext == 'php' || $thumbnail_ext == 'php') {
            $message = "Desculpe, arquivos PHP não são permitidos.";
            $uploadOk = 0;
        }
        
        if ($uploadOk == 1) {
            // Generate unique filenames
            $file_hash = hash_file('sha256', $file["tmp_name"]);
            $new_filename = $file_hash . '.' . $file_ext;
            $target_file = $target_dir . $new_filename;
            
            //$thumbnail_hash = hash_file('sha256', $thumbnail["tmp_name"]);
            $new_thumbnailname = $file_hash . '.' . $thumbnail_ext;
            $target_thumbnail = $target_dir . $new_thumbnailname;
            
            // Move uploaded files
            if (move_uploaded_file($file["tmp_name"], $target_file) && 
                move_uploaded_file($thumbnail["tmp_name"], $target_thumbnail)) {
                
                // Format file size
                $file_size = $file["size"];
                if ($file_size < 1024) {
                    $formatted_size = $file_size . ' bytes';
                } elseif ($file_size < 1048576) {
                    $formatted_size = round($file_size / 1024, 2) . ' KB';
                } else {
                    $formatted_size = round($file_size / 1048576, 2) . ' MB';
                }
                
                // Insert into database
                $sql = "INSERT INTO works (filename, file_hash, file_extension, date, pix_key, file_size, points)
                        VALUES (?, ?, ?, NOW(), ?, ?, ?)";
                
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssd", $file["name"], $file_hash, $file_ext, $pix_key, $formatted_size, $points);
                
if ($stmt->execute()) {
    $message = "Arquivos enviados com sucesso!";
    
    // Save to JSON file
    $data = array(
        'id' => $stmt->insert_id,
        'filename' => $file_hash ."." . $file_ext,
        'file_hash' => $file_hash,
        'file_extension' => $file_ext,
        'date' => date('Y-m-d H:i:s'),
        'pix_key' => $pix_key,
        'file_size' => $formatted_size,
        'points' => $points
    );
    
    $base_filename = 'data_search_json/default';
    $file_index = 0;
    $current_file = $base_filename . '.json';
    
    // Find the appropriate file to write to
    while (true) {
        if (file_exists($current_file)) {
            $current_data = json_decode(file_get_contents($current_file), true) ?: array();
            
            // Check if current file exceeds limits (20 entries or 20KB)
            if (count($current_data) >= 20 || filesize($current_file) >= 20 * 1024) {
                $file_index++;
                $current_file = $base_filename . '_' . $file_index . '.json';
                continue;
            }
        }
        break;
    }
    
    // Add new data to the appropriate file
    $current_data = file_exists($current_file) ? json_decode(file_get_contents($current_file), true) : array();
    $current_data[] = $data;
    file_put_contents($current_file, json_encode($current_data, JSON_PRETTY_PRINT));
} else {
    $message = "Erro ao salvar no banco de dados: " . $conn->error;
}
} else {
    $message = "Desculpe, houve um erro ao enviar seus arquivos.";
}
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload | Professional Platform</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a56d4;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --danger: #f72585;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-radius: 8px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--dark);
            background-color: #f5f7ff;
            padding: 0;
            margin: 0;
        }

        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }

        header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--light-gray);
        }

        h1 {
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .subtitle {
            color: var(--gray);
            font-size: 1.1rem;
        }

        .upload-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .upload-box {
            border: 2px dashed var(--light-gray);
            border-radius: var(--border-radius);
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: var(--transition);
            background-color: #fafbff;
            height: 250px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .upload-box:hover {
            border-color: var(--primary);
            background-color: rgba(67, 97, 238, 0.05);
        }

        .upload-box.active {
            border-color: var(--success);
            background-color: rgba(76, 201, 240, 0.05);
        }

        .upload-box i {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }

        .upload-box p {
            color: var(--gray);
            margin-bottom: 0.5rem;
        }

        .upload-box .file-info {
            font-size: 0.9rem;
            color: var(--gray);
            margin-top: 0.5rem;
        }

        .upload-box input[type="file"] {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }

        .preview {
            max-width: 100%;
            max-height: 180px;
            display: none;
            border-radius: 4px;
            object-fit: contain;
            margin-bottom: 1rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--light-gray);
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: var(--transition);
        }

        input[type="text"]:focus,
        input[type="number"]:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }

        .btn {
            display: inline-block;
            background-color: var(--primary);
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
        }

        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        .alert {
            padding: 1rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            font-weight: 500;
        }

        .alert-success {
            background-color: rgba(76, 201, 240, 0.2);
            color: #0a6c74;
            border-left: 4px solid var(--success);
        }

        .alert-error {
            background-color: rgba(247, 37, 133, 0.2);
            color: #9e1946;
            border-left: 4px solid var(--danger);
        }

        .upload-instructions {
            background-color: #f8f9ff;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 2rem;
            border-left: 4px solid var(--primary);
        }

        .upload-instructions h3 {
            margin-bottom: 0.5rem;
            color: var(--primary);
        }

        .upload-instructions ul {
            padding-left: 1.5rem;
            color: var(--gray);
        }

        .upload-instructions li {
            margin-bottom: 0.5rem;
        }

        @media (max-width: 768px) {
            .container {
                padding: 1.5rem;
                margin: 1rem;
            }
            
            .upload-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-cloud-upload-alt"></i> File Upload</h1>
            <p class="subtitle">Securely upload your files with blockchain verification</p>
        </header>

        <?php if (!empty($message)): ?>
            <div class="alert <?php echo $uploadOk ? 'alert-success' : 'alert-error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="upload-instructions">
            <h3><i class="fas fa-info-circle"></i> Upload Guidelines</h3>
            <ul>
                <li>Maximum file size: 10MB per file</li>
                <li>Supported formats: All standard file types (except .php)</li>
                <li>Files are hashed with SHA-256 for verification</li>
                <li>Thumbnail should be in image format (JPG, PNG, etc.)</li>
            </ul>
        </div>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
            <div class="upload-container">
                <div class="upload-box" id="thumbnail-box">
                    <i class="fas fa-image"></i>
                    <p>Drag & drop your thumbnail here</p>
                    <span class="file-info">or click to browse files</span>
                    <img id="thumbnail-preview" class="preview" alt="Thumbnail preview">
                    <input type="file" name="thumbnail" id="thumbnail" accept="image/*" required>
                </div>
                
                <div class="upload-box" id="file-box">
                    <i class="fas fa-file-upload"></i>
                    <p>Drag & drop your file here</p>
                    <span class="file-info">or click to browse files</span>
                    <img id="file-preview" class="preview" alt="File preview">
                    <input type="file" name="file_upload" id="file_upload" required>
                </div>
            </div>
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="pix_key"><i class="fas fa-key"></i> PIX Key</label>
                    <input type="text" id="pix_key" name="pix_key" placeholder="Enter your PIX key" required>
                </div>
                
                <div class="form-group">
                    <label for="points"><i class="fas fa-bolt"></i> Boost Points</label>
                    <input type="number" id="points" name="points" min="0" step="0.01" placeholder="0.00" required>
                </div>
            </div>
            
            <button type="submit" class="btn btn-block">
                <i class="fas fa-paper-plane"></i> Upload Files
            </button>
        </form>
    </div>

    <script>
        // Enhanced file upload with drag & drop and better previews
        document.addEventListener('DOMContentLoaded', function() {
            const thumbnailBox = document.getElementById('thumbnail-box');
            const fileBox = document.getElementById('file-box');
            const thumbnailInput = document.getElementById('thumbnail');
            const fileInput = document.getElementById('file_upload');
            
            // Setup drag and drop for both boxes
            [thumbnailBox, fileBox].forEach(box => {
                box.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    box.classList.add('active');
                });
                
                box.addEventListener('dragleave', () => {
                    box.classList.remove('active');
                });
                
                box.addEventListener('drop', (e) => {
                    e.preventDefault();
                    box.classList.remove('active');
                    
                    const input = box === thumbnailBox ? thumbnailInput : fileInput;
                    if (e.dataTransfer.files.length) {
                        input.files = e.dataTransfer.files;
                        updatePreview(input);
                    }
                });
            });
            
            // Handle file selection
            thumbnailInput.addEventListener('change', function() {
                updatePreview(this);
            });
            
            fileInput.addEventListener('change', function() {
                updatePreview(this);
            });
            
            function updatePreview(input) {
                const file = input.files[0];
                if (!file) return;
                
                const box = input === thumbnailInput ? thumbnailBox : fileBox;
                const previewId = input === thumbnailInput ? 'thumbnail-preview' : 'file-preview';
                const preview = document.getElementById(previewId);
                const icon = box.querySelector('i');
                const text = box.querySelector('p');
                const fileInfo = box.querySelector('.file-info');
                
                // Update file info
                fileInfo.textContent = `${file.name} (${formatFileSize(file.size)})`;
                
                // Show preview if image
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                        icon.style.display = 'none';
                        text.style.display = 'none';
                    }
                    reader.readAsDataURL(file);
                } else {
                    preview.style.display = 'none';
                    icon.style.display = 'block';
                    text.style.display = 'block';
                    icon.className = getFileIcon(file);
                }
            }
            
            function formatFileSize(bytes) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            }
            
            function getFileIcon(file) {
                const type = file.type.split('/')[0];
                const extension = file.name.split('.').pop().toLowerCase();
                const fileIcons = {
                    image: 'fas fa-image',
                    audio: 'fas fa-music',
                    video: 'fas fa-film',
                    text: 'fas fa-file-alt',
                    pdf: 'fas fa-file-pdf',
                    zip: 'fas fa-file-archive',
                    excel: 'fas fa-file-excel',
                    word: 'fas fa-file-word',
                    powerpoint: 'fas fa-file-powerpoint',
                    code: 'fas fa-file-code'
                };
                
                const extensionIcons = {
                    pdf: 'pdf',
                    xls: 'excel', xlsx: 'excel',
                    doc: 'word', docx: 'word',
                    ppt: 'powerpoint', pptx: 'powerpoint',
                    zip: 'zip', rar: 'zip', '7z': 'zip',
                    js: 'code', html: 'code', css: 'code', php: 'code', json: 'code'
                };
                
                if (extensionIcons[extension]) {
                    return fileIcons[extensionIcons[extension]];
                }
                
                return fileIcons[type] || 'fas fa-file';
            }
            
            // Form validation
            document.querySelector('form').addEventListener('submit', function(e) {
                let valid = true;
                
                if (!thumbnailInput.files.length || !fileInput.files.length) {
                    alert('Please select both a thumbnail and a file to upload');
                    valid = false;
                }
                
                [thumbnailInput, fileInput].forEach(input => {
                    if (input.files.length) {
                        const file = input.files[0];
                        if (file.size > 10 * 1024 * 1024) {
                            alert(`File "${file.name}" is too large. Maximum size is 10MB.`);
                            valid = false;
                        }
                        
                        if (file.name.split('.').pop().toLowerCase() === 'php') {
                            alert('PHP files are not allowed for security reasons.');
                            valid = false;
                        }
                    }
                });
                
                if (!valid) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>