<?php
session_start();

// File upload configuration
$uploadDir = 'files/';
$maxFileSize = 10 * 1024 * 1024; // 10 MB

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['uploadedFile'])) {
    $file = $_FILES['uploadedFile'];
    
    // Check file size
    if ($file['size'] > $maxFileSize) {
        die('Error: File size exceeds the maximum limit of 10MB.');
    }
    
    // Check file extension (disallow .php files)
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($fileExtension == 'php') {
        die('Error: PHP files are not allowed.');
    }
    
    // Create the files directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Generate a SHA256 hash for the file
    $fileHash = hash_file('sha256', $file['tmp_name']);
    $newFileName = $fileHash . '.' . $fileExtension;
    $filePath = $uploadDir . $newFileName;

    // Check if the file already exists
    if (file_exists($filePath)) {
        die('Error: File already exists.');
    }

    // Move the uploaded file to the 'files' directory
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        echo "File successfully uploaded.";

        // Check if $_SESSION['user'] is set and not empty
        if (isset($_SESSION['user']) && !empty($_SESSION['user'])) {
            $userDir = 'users/' . $_SESSION['user'] . '/';
            
            // Create user directory if it doesn't exist
            if (!is_dir($userDir)) {
                mkdir($userDir, 0755, true);
            }

            // Write the hash of the file to a text file inside the user's folder using fopen
            $hashFile = $userDir . $fileHash;
            $fileHandle = fopen($hashFile, 'a'); // Open file in append mode
            
            if ($fileHandle) {
                fwrite($fileHandle, ""); // Write the hash to the file
                fclose($fileHandle); // Close the file
                echo " Hash saved to user's directory.";
            } else {
                echo "Error: Failed to write hash to the user's directory.";
            }
        }
    } else {
        echo "Error: Failed to upload file.";
    }
}
?>

<!-- HTML Form for file upload -->
<form action="" method="post" enctype="multipart/form-data">
    Select file to upload (Max 10MB):
    <input type="file" name="uploadedFile" required>
    <input type="submit" value="Upload File">
</form>
