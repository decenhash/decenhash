<?php
// update_musics.php - Run this script to update the musics.json file

$musicDir = 'musics/';
$outputFile = 'musics.json';
$allowedExtensions = ['mp3'];

$musicData = [];

if (is_dir($musicDir)) {
    if ($dh = opendir($musicDir)) {
        while (($file = readdir($dh)) !== false) {
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            if (in_array(strtolower($ext), $allowedExtensions)) {
                $fileName = pathinfo($file, PATHINFO_FILENAME);
                
                // Extract artist/thumbnail name (text before '-')
                $thumbName = $fileName;
                if (strpos($fileName, '-') !== false) {
                    $parts = explode('-', $fileName, 2);
                    $thumbName = trim($parts[0]);
                }
                
                $thumbPath = $musicDir . $thumbName . '.jpg';
                
                // Default thumbnail if not found
                if (!file_exists($thumbPath)) {
                    $thumbPath = 'https://via.placeholder.com/300x300/282828/ffffff?text=' . urlencode($thumbName);
                }
                
                // Song title (text after '-')
                $songTitle = $fileName;
                if (strpos($fileName, '-') !== false) {
                    $parts = explode('-', $fileName, 2);
                    $songTitle = trim($parts[1]);
                }
                
                $musicData[] = [
                    'filePath' => $musicDir . $file,
                    'thumbPath' => $thumbPath,
                    'title' => $songTitle,
                    'artist' => $thumbName
                ];
            }
        }
        closedir($dh);
    }
}

// Sort by artist then title
usort($musicData, function($a, $b) {
    return strcmp($a['artist'], $b['artist']) ?: strcmp($a['title'], $b['title']);
});

file_put_contents($outputFile, json_encode($musicData, JSON_PRETTY_PRINT));
echo "musics.json updated successfully with " . count($musicData) . " songs.";
?>