import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ServerUrlProcessor {
    private static final String SERVERS_DIRECTORY = "servers";
    private static final String OUTPUT_DIRECTORY = "servers";

    public static void main(String[] args) {
        // Create output directory if it doesn't exist
        createOutputDirectoryIfNotExists();

        // Get list of files in servers directory
        File serversDir = new File(SERVERS_DIRECTORY);
        File[] serverFiles = serversDir.listFiles();

        if (serverFiles == null || serverFiles.length == 0) {
            System.out.println("No files found in the servers directory.");
            return;
        }

        // Process each file
        for (File file : serverFiles) {
            try {
                // Read file content
                String urlContent = Files.readString(file.toPath()).trim();

                // Validate URL
                URL url = new URL(urlContent);

                // Try to connect
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                int responseCode = connection.getResponseCode();
                System.out.println("URL: " + urlContent + ", Response Code: " + responseCode);

                // Generate filename using SHA-256 of IP
                String ipAddress = url.getHost();
                String hashedFilename = generateSHA256(ipAddress);

                // Save content to new file
                saveContentToFile(hashedFilename, urlContent);

                // Delete original file
                Files.delete(file.toPath());

                System.out.println("Processed file: " + file.getName());

            } catch (Exception e) {
                System.err.println("Error processing file " + file.getName() + ": " + e.getMessage());
            }
        }
    }

    private static void createOutputDirectoryIfNotExists() {
        File outputDir = new File(OUTPUT_DIRECTORY);
        if (!outputDir.exists()) {
            boolean created = outputDir.mkdirs();
            if (created) {
                System.out.println("Created output directory: " + OUTPUT_DIRECTORY);
            } else {
                System.err.println("Failed to create output directory.");
            }
        }
    }

    private static String generateSHA256(String input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedhash = digest.digest(input.getBytes());
        
        // Convert to hexadecimal
        StringBuilder hexString = new StringBuilder(2 * encodedhash.length);
        for (byte b : encodedhash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        
        return hexString.toString();
    }

    private static void saveContentToFile(String filename, String content) throws IOException {
        Path outputPath = Paths.get(OUTPUT_DIRECTORY, filename + ".txt");
        try (FileWriter writer = new FileWriter(outputPath.toFile())) {
            writer.write(content);
        }
        System.out.println("Saved file: " + outputPath);
    }
}