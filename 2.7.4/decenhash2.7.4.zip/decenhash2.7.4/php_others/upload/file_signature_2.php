<?php
// Create blocks_json directory if it doesn't exist
if (!file_exists('blocks_json')) {
    mkdir('blocks_json', 0755, true);
}

// Handle form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'timestamp' => date('c'),
        'pix' => $_POST['pix'] ?? '',
        'btc' => $_POST['btc'] ?? '',
        'signature_password' => $_POST['signature_password'] ?? '',
        'other_info' => $_POST['other_info'] ?? '',
        'file_extension' => '',
        'file_hash' => '',
        'signature' => ''
    ];

    // Handle file upload or text input
    if (!empty($_FILES['file_upload']['tmp_name'])) {
        $fileContent = file_get_contents($_FILES['file_upload']['tmp_name']);
        $data['file_hash'] = hash('sha256', $fileContent);
        $data['file_extension'] = pathinfo($_FILES['file_upload']['name'], PATHINFO_EXTENSION);
    } elseif (!empty($_POST['text_input'])) {
        $data['file_hash'] = hash('sha256', $_POST['text_input']);
        $data['file_extension'] = 'txt';
    }

    // Generate signature
    if (!empty($data['signature_password'])) {
        $data['signature'] = hash('sha256', $data['signature_password'] . $data['file_hash']);
    }

    // Save to JSON file if hash exists and file doesn't exist
    if (!empty($data['file_hash'])) {
        $filename = "blocks_json/{$data['file_hash']}.json";
        if (!file_exists($filename)) {
            include("ip_hash.php");
            file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT));
            $message = "Data saved successfully!"; 
        } else {
            $message = "File with this hash already exists. No changes made.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Hash Signature System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #2c3e50;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            background: #dff0d8;
            color: #3c763d;
            border-radius: 4px;
            border: 1px solid #d6e9c6;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"],
        input[type="file"],
        textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .radio-group {
            display: flex;
            gap: 15px;
        }

        .radio-group label {
            font-weight: normal;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        button {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        button:hover {
            background-color: #2980b9;
        }

        .hash-display {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 4px;
            border: 1px solid #ddd;
        }

        #hashValue {
            font-family: monospace;
            word-break: break-all;
            padding: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>File Hash Signature System</h1>
        
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="pix">PIX Key:</label>
                <input type="text" id="pix" name="pix" placeholder="Enter your PIX key">
            </div>
            
            <div class="form-group">
                <label for="btc">BTC Address:</label>
                <input type="text" id="btc" name="btc" placeholder="Enter your BTC address">
            </div>
            
            <div class="form-group">
                <label for="signature_password">Signature Password:</label>
                <input type="password" id="signature_password" name="signature_password" placeholder="Enter a password for signature">
            </div>
            
            <div class="form-group">
                <label for="other_info">Other Information:</label>
                <textarea id="other_info" name="other_info" placeholder="Any additional information"></textarea>
            </div>
            
            <div class="form-group">
                <label>File Input Method:</label>
                <div class="radio-group">
                    <label>
                        <input type="radio" name="input_method" value="upload" checked> Upload File
                    </label>
                    <label>
                        <input type="radio" name="input_method" value="text"> Enter Text
                    </label>
                </div>
            </div>
            
            <div class="form-group" id="upload-section">
                <label for="file_upload">Upload File:</label>
                <input type="file" id="file_upload" name="file_upload">
            </div>
            
            <div class="form-group" id="text-section" style="display: none;">
                <label for="text_input">Enter Text:</label>
                <textarea id="text_input" name="text_input" placeholder="Enter text to hash"></textarea>
            </div>
            
            <button type="submit">Submit</button>
        </form>
        
        <div class="hash-display" id="hashDisplay" style="display: none;">
            <h3>Generated SHA-256 Hash:</h3>
            <div id="hashValue"></div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const inputMethodRadios = document.querySelectorAll('input[name="input_method"]');
            const uploadSection = document.getElementById('upload-section');
            const textSection = document.getElementById('text-section');
            const fileUpload = document.getElementById('file_upload');
            const textInput = document.getElementById('text_input');
            const hashDisplay = document.getElementById('hashDisplay');
            const hashValue = document.getElementById('hashValue');
            
            // Toggle between file upload and text input
            inputMethodRadios.forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.value === 'upload') {
                        uploadSection.style.display = 'block';
                        textSection.style.display = 'none';
                    } else {
                        uploadSection.style.display = 'none';
                        textSection.style.display = 'block';
                    }
                });
            });
            
            // Calculate hash for file upload
            fileUpload.addEventListener('change', function(e) {
                if (this.files.length > 0) {
                    const file = this.files[0];
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        const content = e.target.result;
                        calculateHash(content);
                    };
                    
                    reader.readAsArrayBuffer(file);
                }
            });
            
            // Calculate hash for text input
            textInput.addEventListener('input', function() {
                if (this.value.trim() !== '') {
                    calculateHash(this.value);
                } else {
                    hashDisplay.style.display = 'none';
                }
            });
            
            // Calculate SHA-256 hash
            function calculateHash(content) {
                if (typeof content !== 'string') {
                    // Convert ArrayBuffer to Uint8Array for crypto.subtle
                    content = new Uint8Array(content);
                }
                
                if (window.crypto && window.crypto.subtle) {
                    // For modern browsers with crypto.subtle support
                    if (content instanceof Uint8Array) {
                        // For file content
                        window.crypto.subtle.digest('SHA-256', content)
                            .then(hash => {
                                displayHash(hash);
                            });
                    } else {
                        // For text content
                        const encoder = new TextEncoder();
                        const data = encoder.encode(content);
                        window.crypto.subtle.digest('SHA-256', data)
                            .then(hash => {
                                displayHash(hash);
                            });
                    }
                } else {
                    // Fallback for browsers without crypto.subtle
                    try {
                        let hash;
                        if (content instanceof Uint8Array) {
                            // Simple fallback for files - not secure for large files
                            let str = '';
                            for (let i = 0; i < content.length; i++) {
                                str += String.fromCharCode(content[i]);
                            }
                            hash = sha256(str);
                        } else {
                            hash = sha256(content);
                        }
                        displayHashHex(hash);
                    } catch (e) {
                        console.error("Hash calculation failed:", e);
                    }
                }
            }
            
            // Display hash from ArrayBuffer
            function displayHash(buffer) {
                const hashArray = Array.from(new Uint8Array(buffer));
                const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
                hashValue.textContent = hashHex;
                hashDisplay.style.display = 'block';
            }
            
            // Display hash from hex string (fallback)
            function displayHashHex(hex) {
                hashValue.textContent = hex;
                hashDisplay.style.display = 'block';
            }
            
            // Simple SHA-256 implementation for fallback
            function sha256(str) {
                // This is a very simplified version and not suitable for production
                // In a real application, you should use a proper SHA-256 library
                let hash = 0;
                for (let i = 0; i < str.length; i++) {
                    const char = str.charCodeAt(i);
                    hash = (hash << 5) - hash + char;
                    hash |= 0; // Convert to 32bit integer
                }
                return hash.toString(16);
            }
        });
    </script>
</body>
</html>