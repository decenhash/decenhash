<?php
// PHP code to handle file saving
$message = '';
$save_dir = 'JSON';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure content is provided
    if (!isset($_POST['content']) || empty(trim($_POST['content']))) {
        $message = '<span style="color:red;">Error: Content cannot be empty.</span>';
    } else {
        $content = $_POST['content'];
        $filename = '';

        // Determine the filename based on user choice
        if (isset($_POST['filename_choice']) && $_POST['filename_choice'] === 'hash') {
            $filename = hash('sha256', $content);
        } elseif (isset($_POST['filename_choice']) && $_POST['filename_choice'] === 'custom' && !empty(trim($_POST['custom_name']))) {
            $custom_name = trim($_POST['custom_name']);
            // Validate the custom filename: letters, numbers, and underscore only
            if (preg_match('/^[a-zA-Z0-9_]+$/', $custom_name)) {
                $filename = $custom_name;
            } else {
                $message = '<span style="color:red;">Error: Custom filename can only contain letters, numbers, and underscores.</span>';
            }
        } else {
             $message = '<span style="color:red;">Error: Please provide a valid filename.</span>';
        }

        // If a valid filename was determined, proceed with saving
        if (!empty($filename)) {
            $filepath = $save_dir . '/' . $filename . '.html';

            // Check if the directory exists, and create it if not
            if (!is_dir($save_dir)) {
                mkdir($save_dir, 0755, true);
            }

            // Check if the file already exists before saving
            if (file_exists($filepath)) {
                $message = '<span style="color:orange;">Warning: A file with that name already exists. Not saved.</span>';
            } else {
                // Save the content to the file
                if (file_put_contents($filepath, $content) !== false) {
                    $message = '<span style="color:green;">Success! File saved. <a href="' . htmlspecialchars($filepath) . '" target="_blank">Click here to view the file</a>.</span>';
                } else {
                    $message = '<span style="color:red;">Error: Failed to save the file. Check folder permissions.</span>';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Saver Program</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            width: 90%;
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 1.5rem;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        textarea {
            width: 100%;
            padding: 1rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            resize: vertical;
            min-height: 200px;
            font-size: 1rem;
        }
        .radio-group {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
        }
        .radio-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        input[type="text"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 0.75rem;
            border: none;
            border-radius: 8px;
            font-size: 1.25rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 1rem;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Save Content to a File</h1>
        <?php if (!empty($message)): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <form action="" method="post">
            <textarea name="content" placeholder="Enter the content you want to save..." required></textarea>
            
            <div class="radio-group">
                <p>Choose a filename option:</p>
                <div class="radio-item">
                    <input type="radio" id="hash" name="filename_choice" value="hash" checked>
                    <label for="hash">Use SHA-256 hash of the content</label>
                </div>
                <div class="radio-item">
                    <input type="radio" id="custom" name="filename_choice" value="custom">
                    <label for="custom">Use a custom name (only letters, numbers, and '_')</label>
                </div>
            </div>

            <input type="text" id="custom_name" name="custom_name" placeholder="Enter custom filename..." disabled>
            
            <button type="submit">Save File</button>
        </form>
    </div>

    <script>
        // JavaScript to handle the UI logic
        document.addEventListener('DOMContentLoaded', () => {
            const hashRadio = document.getElementById('hash');
            const customRadio = document.getElementById('custom');
            const customNameInput = document.getElementById('custom_name');
            const form = document.querySelector('form');
            const contentTextarea = document.querySelector('textarea[name="content"]');

            // Function to toggle the custom name input field
            function toggleCustomNameInput() {
                customNameInput.disabled = !customRadio.checked;
                customNameInput.required = customRadio.checked;
                if (!customRadio.checked) {
                    customNameInput.value = ''; // Clear the input when disabled
                }
            }

            // Add event listeners to the radio buttons
            hashRadio.addEventListener('change', toggleCustomNameInput);
            customRadio.addEventListener('change', toggleCustomNameInput);

            // Initial state check
            toggleCustomNameInput();

            // Form validation to prevent empty content on the client-side
            form.addEventListener('submit', (e) => {
                if (contentTextarea.value.trim() === '') {
                    e.preventDefault(); // Stop form submission
                    // Instead of alert(), show a message in a div
                    const messageContainer = document.querySelector('.message');
                    if (messageContainer) {
                        messageContainer.innerHTML = '<span style="color:red;">Error: Content cannot be empty!</span>';
                    }
                }
            });
        });
    </script>
</body>
</html>
