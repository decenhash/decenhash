<?php

function main() {
    $root = "./arts";
    $rootIndexContent = "<html><body><ul>"; // Content for the main index.html

    // Walk through the directory and handle directories
    $files = scandir($root);
    foreach ($files as $file) {
        $path = $root . '/' . $file;
        if (is_dir($path) && $file != '.' && $file != '..') {
            // Get the list of files in the directory
            $filesInDir = scandir($path);
            // Create the HTML content with img tags
            $htmlContent = "<html><body><div align='center'>";
            foreach ($filesInDir as $fileInDir) {
                // Check if the file is an image
                if (isImage($fileInDir)) {
                    // Set the src attribute with only the file name
                    $src = $fileInDir;
                    $htmlContent .= "<a href=\"$src\"><img src=\"$src\" width=\"50%\"></a><br><br>";
                }
            }
            $htmlContent .= "</div></body></html>";

            // Write HTML content to a file in the directory
            $htmlFilePath = $path . "/index.html";
            file_put_contents($htmlFilePath, $htmlContent);

            // Add a link to this directory's index.html to the root index.html
            $rootIndexContent .= "<li><a href=\"$path/index.html\">$file</a></li>";

            echo "Created HTML file: $htmlFilePath\n";
        }
    }

    // Finalize and write the main index.html
    $rootIndexContent .= "</ul></body></html>";
    file_put_contents($root . "/../index.html", $rootIndexContent);

    echo "Created root index.html\n";
}

// isImage checks if a file is an image based on its extension
function isImage($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    switch ($ext) {
        case "jpg":
        case "jpeg":
        case "png":
        case "gif":
            return true;
        default:
            return false;
    }
}

main();

?>
