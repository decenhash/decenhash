<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'decenhash');
define('MUSICS_DIR', 'musics');

// Create musics directory if it doesn't exist
if (!file_exists(MUSICS_DIR)) {
    mkdir(MUSICS_DIR, 0755, true);
}

// Create database connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create musics table if it doesn't exist
$createTableSQL = "CREATE TABLE IF NOT EXISTS musics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    artist VARCHAR(255) NOT NULL,
    genre VARCHAR(100) NOT NULL,
    thumb VARCHAR(255),
    file VARCHAR(255) NOT NULL,
    review TEXT,
    plays INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if (!$conn->query($createTableSQL)) {
    die("Error creating table: " . $conn->error);
}

// Process form submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $title = trim($_POST['title'] ?? '');
    $artist = trim($_POST['artist'] ?? '');
    $genre = trim($_POST['genre'] ?? '');
    $thumb = trim($_POST['thumb'] ?? '');
    $file = trim($_POST['file'] ?? '');
    $review = trim($_POST['review'] ?? '');
    
    // Basic validation
    if (empty($title) || empty($artist) || empty($genre) || empty($file)) {
        $message = '<div class="alert error">Please fill in all required fields</div>';
    } else {
        // Prepare data for JSON
        $musicData = [
            'title' => $title,
            'artist' => $artist,
            'genre' => $genre,
            'thumb' => $thumb,
            'file' => $file,
            'review' => $review,
            'plays' => 0,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // Generate filename as hash of content
        $jsonContent = json_encode($musicData, JSON_PRETTY_PRINT);
        $filename = hash('sha256', $jsonContent) . '.json';
        $filepath = MUSICS_DIR . '/' . $filename;
        
        // Save to JSON file
        if (file_put_contents($filepath, $jsonContent)) {
            // Insert into MySQL
            $stmt = $conn->prepare("INSERT INTO musics (title, artist, genre, thumb, file, review) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssss", $title, $artist, $genre, $thumb, $file, $review);
            
            if ($stmt->execute()) {
                $message = '<div class="alert success">Music track added successfully!</div>';
            } else {
                $message = '<div class="alert error">Error saving to database: ' . $stmt->error . '</div>';
                // Remove the JSON file if DB insert failed
                unlink($filepath);
            }
            $stmt->close();
        } else {
            $message = '<div class="alert error">Error saving to JSON file</div>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Music Track</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        .required:after {
            content: " *";
            color: red;
        }
        button {
            background-color: #1DB954;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #19a64b;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
        }
        .success {
            background-color: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #a5d6a7;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add New Music Track</h1>
        
        <?php echo $message; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="title" class="required">Title</label>
                <input type="text" id="title" name="title" required>
            </div>
            
            <div class="form-group">
                <label for="artist" class="required">Artist</label>
                <input type="text" id="artist" name="artist" required>
            </div>
            
            <div class="form-group">
                <label for="genre" class="required">Genre</label>
                <input type="text" id="genre" name="genre" required>
            </div>
            
            <div class="form-group">
                <label for="thumb">Thumbnail URL</label>
                <input type="text" id="thumb" name="thumb">
            </div>
            
            <div class="form-group">
                <label for="file" class="required">Audio File URL</label>
                <input type="text" id="file" name="file" required>
            </div>
            
            <div class="form-group">
                <label for="review">Review</label>
                <textarea id="review" name="review"></textarea>
            </div>
            
            <button type="submit">Add Track</button>
        </form>
    </div>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>