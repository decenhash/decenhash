<?php
// index.php
$imagesDirectory = 'images/';
$likesDirectory = 'likes/';

// Create likes directory if it doesn't exist
if (!file_exists($likesDirectory)) {
    mkdir($likesDirectory, 0755, true);
}

// Get all image files from the images directory
$allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
$images = [];

if (file_exists($imagesDirectory) && is_dir($imagesDirectory)) {
    $files = scandir($imagesDirectory);
    
    foreach ($files as $file) {
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if ($file !== '.' && $file !== '..' && in_array($extension, $allowedExtensions)) {
            $images[] = $file;
        }
    }
}

// Get client IP address
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Handle image like/dislike
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['image'])) {
    $image = $_POST['image'];
    $action = $_POST['action'];
    
    if ($action === 'like') {
        $userIP = getClientIP();
        $salt = "start";
        $hash = hash('sha256', $userIP . $salt);
        
        // Create a file in the likes directory
        file_put_contents($likesDirectory . $hash . '_' . $image, '');
        echo json_encode(['status' => 'success']);
        exit;
    }
    
    echo json_encode(['status' => 'success']);
    exit;
}

// Select a random image or use the one from the query parameter
$selectedImage = isset($_GET['image']) && in_array($_GET['image'], $images) 
    ? $_GET['image'] 
    : (count($images) > 0 ? $images[array_rand($images)] : '');

// Get URL for selected image
$selectedImageUrl = $selectedImage ? $imagesDirectory . $selectedImage : '';

// Get next image for navigation
function getNextImage($currentImage, $images) {
    if (empty($images)) return '';
    
    $currentIndex = array_search($currentImage, $images);
    $nextIndex = ($currentIndex + 1) % count($images);
    return $images[$nextIndex];
}

$nextImage = getNextImage($selectedImage, $images);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fullscreen Image Viewer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #000;
            color: #fff;
            overflow: hidden;
            height: 100vh;
            width: 100vw;
        }
        
        .viewer {
            position: relative;
            width: 100vw;
            height: 100vh;
            overflow: hidden;
        }
        
        .fullscreen-image {
            position: absolute;
            width: 100%;
            height: 100%;
            object-fit: cover; /* This makes the image cover the entire container, cropping if needed */
        }
        
        .no-image {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #777;
            font-size: 1.5em;
        }
        
        .rating-controls {
            position: absolute;
            bottom: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.6);
            padding: 10px;
            border-radius: 50px;
            display: flex;
            gap: 15px;
            z-index: 10;
        }
        
        .rating-btn {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            transition: transform 0.2s, color 0.2s;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .rating-btn:hover {
            transform: scale(1.2);
        }
        
        .like-btn:hover {
            color: #4CAF50;
        }
        
        .dislike-btn:hover {
            color: #F44336;
        }
        
        .next-btn {
            position: absolute;
            top: 50%;
            right: 20px;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 24px;
            transition: background-color 0.2s;
            z-index: 10;
        }
        
        .next-btn:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }
        
        .toast {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            opacity: 0;
            transition: opacity 0.3s;
            z-index: 100;
        }
        
        .toast.show {
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="viewer">
        <?php if ($selectedImage): ?>
            <img class="fullscreen-image" 
                 src="<?php echo htmlspecialchars($selectedImageUrl); ?>" 
                 alt="<?php echo htmlspecialchars($selectedImage); ?>" 
                 id="fullscreenImage">
                 
            <div class="rating-controls">
                <button class="rating-btn like-btn" title="Like" id="likeBtn">
                    <i class="fas fa-thumbs-up"></i>
                </button>
                <button class="rating-btn dislike-btn" title="Dislike" id="dislikeBtn">
                    <i class="fas fa-thumbs-down"></i>
                </button>
            </div>
            
            <button class="next-btn" id="nextBtn" title="Next Image">
                <i class="fas fa-chevron-right"></i>
            </button>
        <?php else: ?>
            <div class="no-image">No images available</div>
        <?php endif; ?>
    </div>
    
    <div class="toast" id="toast"></div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const likeBtn = document.getElementById('likeBtn');
            const dislikeBtn = document.getElementById('dislikeBtn');
            const nextBtn = document.getElementById('nextBtn');
            const toast = document.getElementById('toast');
            
            // Show toast notification
            function showToast(message, duration = 2000) {
                toast.textContent = message;
                toast.classList.add('show');
                
                setTimeout(() => {
                    toast.classList.remove('show');
                }, duration);
            }
            
            // Next image button
            if (nextBtn) {
                nextBtn.addEventListener('click', function() {
                    window.location.href = '?image=<?php echo urlencode($nextImage); ?>';
                });
            }
            
            // Handle keyboard navigation
            document.addEventListener('keydown', function(event) {
                if (event.key === 'ArrowRight' || event.code === 'Space') {
                    window.location.href = '?image=<?php echo urlencode($nextImage); ?>';
                }
            });
            
            // Handle like/dislike actions
            if (likeBtn && dislikeBtn) {
                likeBtn.addEventListener('click', function() {
                    rateImage('like');
                });
                
                dislikeBtn.addEventListener('click', function() {
                    rateImage('dislike');
                });
                
                function rateImage(action) {
                    const currentImage = '<?php echo $selectedImage; ?>';
                    
                    if (!currentImage) return;
                    
                    fetch('', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `action=${action}&image=${encodeURIComponent(currentImage)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            showToast(`Image ${action === 'like' ? 'liked' : 'disliked'} successfully`);
                            
                            // Visual feedback
                            if (action === 'like') {
                                likeBtn.style.color = '#4CAF50';
                                setTimeout(() => { likeBtn.style.color = ''; }, 1000);
                            } else {
                                dislikeBtn.style.color = '#F44336';
                                setTimeout(() => { dislikeBtn.style.color = ''; }, 1000);
                            }
                            
                            // Move to next image after rating
                            setTimeout(() => {
                                window.location.href = '?image=<?php echo urlencode($nextImage); ?>';
                            }, 1500);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('An error occurred');
                    });
                }
            }
            
            // Touch gestures for mobile
            let touchStartX = 0;
            
            document.addEventListener('touchstart', function(e) {
                touchStartX = e.changedTouches[0].screenX;
            });
            
            document.addEventListener('touchend', function(e) {
                const touchEndX = e.changedTouches[0].screenX;
                const diff = touchStartX - touchEndX;
                
                // If swipe left, go to next image
                if (diff > 50) {
                    window.location.href = '?image=<?php echo urlencode($nextImage); ?>';
                }
            });
        });
    </script>
</body>
</html>