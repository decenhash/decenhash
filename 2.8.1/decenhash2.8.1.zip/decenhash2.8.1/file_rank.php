﻿<?php
// Initialize variables to avoid errors
$filehash = '';
$results = [];
$total_hash_deposit = 0;
$error_message = '';
$has_results = false;

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['filehash'])) {
    // Include the database configuration
    // Database host (e.g., "localhost" or "127.0.0.1")
define('DB_SERVER', 'localhost');

// Your database username
define('DB_USERNAME', 'root');

// Your database password
define('DB_PASSWORD', '');

// The name of the database you want to use
define('DB_NAME', 'decenhash');

/*
 * -------------------------------------------------------------------------
 * Establish Database Connection
 * -------------------------------------------------------------------------
 *
 * The following code attempts to connect to the MySQL database using the
 * credentials defined above. It uses the MySQLi extension.
 * If the connection fails, it will terminate the script and display an
 * error message.
 *
 */
$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check for connection errors
if ($mysqli->connect_errno) {
    // Using die() will exit the script and display the error.
    // In a production environment, you might want to handle this more gracefully.
    die("ERROR: Could not connect to the database. " . $mysqli->connect_error);
}

    // Sanitize the user input to prevent SQL injection
    $filehash = trim($_POST['filehash']);

    // --- Step 1: Get the total sum of deposits for the given filehash ---
    $sql_total = "SELECT SUM(deposit) as total FROM hashstock WHERE filehash = ?";
    if ($stmt_total = $mysqli->prepare($sql_total)) {
        $stmt_total->bind_param("s", $filehash);
        if ($stmt_total->execute()) {
            $result_total = $stmt_total->get_result();
            if ($row_total = $result_total->fetch_assoc()) {
                // Use floatval to ensure it's a number, default to 0 if null
                $total_hash_deposit = floatval($row_total['total']);
            }
        } else {
            $error_message = "Error executing total deposit query.";
        }
        $stmt_total->close();
    } else {
        $error_message = "Error preparing total deposit query.";
    }


    // --- Step 2: Get top 100 users by their total deposit for the hash ---
    // Proceed only if the total deposit is greater than 0
    if (empty($error_message) && $total_hash_deposit > 0) {
        $sql_users = "
            SELECT
                u.username,
                SUM(h.deposit) AS user_total_deposit
            FROM
                hashstock h
            JOIN
                users u ON h.user_id = u.id
            WHERE
                h.filehash = ?
            GROUP BY
                h.user_id, u.username
            ORDER BY
                user_total_deposit DESC
            LIMIT 100
        ";

        if ($stmt_users = $mysqli->prepare($sql_users)) {
            $stmt_users->bind_param("s", $filehash);
            if ($stmt_users->execute()) {
                $results = $stmt_users->get_result()->fetch_all(MYSQLI_ASSOC);
                $has_results = count($results) > 0;
            } else {
                $error_message = "Error executing user deposit query.";
            }
            $stmt_users->close();
        } else {
            $error_message = "Error preparing user deposit query.";
        }
    } elseif (empty($error_message)) {
        $error_message = "No deposits found for the specified hash.";
    }

    // Close the database connection
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filehash Deposit Viewer</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        .progress-bar {
            background-color: #e5e7eb;
            border-radius: 0.5rem;
            overflow: hidden;
        }
        .progress-bar-inner {
            background-color: #3b82f6;
            height: 100%;
            text-align: center;
            color: white;
            line-height: 1.25rem;
            transition: width 0.3s ease-in-out;
        }
    </style>
</head>
<body class="bg-gray-100 text-gray-800">

    <div class="container mx-auto p-4 md:p-8 max-w-4xl">
        <div class="bg-white rounded-xl shadow-lg p-6 md:p-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Filehash Deposit Analyzer</h1>
            <p class="text-gray-600 mb-6">Enter a filehash to see the top 100 depositors and their contribution percentage.</p>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="flex flex-col sm:flex-row gap-2">
                    <input
                        type="text"
                        name="filehash"
                        id="filehash"
                        placeholder="Enter filehash here..."
                        value="<?php echo htmlspecialchars($filehash); ?>"
                        class="flex-grow w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
                        required
                    >
                    <button type="submit" class="bg-blue-600 text-white font-semibold px-6 py-3 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-transform transform hover:scale-105">
                        Search
                    </button>
                </div>
            </form>
        </div>

        <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
            <div class="bg-white rounded-xl shadow-lg p-6 md:p-8 mt-8">
                <h2 class="text-2xl font-bold text-gray-900 mb-4">Results</h2>
                <?php if (!empty($error_message)): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
                        <p class="font-bold">Error</p>
                        <p><?php echo htmlspecialchars($error_message); ?></p>
                    </div>
                <?php elseif ($has_results): ?>
                    <div class="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <p class="text-gray-700">Total deposits for this hash: <strong class="text-blue-700 font-bold">$<?php echo number_format($total_hash_deposit, 2); ?></strong></p>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Deposit</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contribution</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($results as $index => $row): ?>
                                    <?php
                                        // Calculate percentage
                                        $percentage = ($total_hash_deposit > 0) ? ($row['user_total_deposit'] / $total_hash_deposit) * 100 : 0;
                                    ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo $index + 1; ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-800"><?php echo htmlspecialchars($row['username']); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-semibold">$<?php echo number_format($row['user_total_deposit'], 2); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <div class="w-full">
                                                <div class="text-blue-600 font-semibold mb-1"><?php echo number_format($percentage, 2); ?>%</div>
                                                <div class="progress-bar w-full h-5">
                                                    <div class="progress-bar-inner text-xs font-medium" style="width: <?php echo number_format($percentage, 2); ?>%;">
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                     <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md" role="alert">
                        <p class="font-bold">No Results</p>
                        <p>No deposit records were found for the submitted hash. Please check the hash and try again.</p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    </div>
</body>
</html>
