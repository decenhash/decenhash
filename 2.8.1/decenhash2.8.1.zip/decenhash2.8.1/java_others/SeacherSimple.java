import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 *
 * It searches across a predefined list of servers for resources based on user input.
 *
 * HOW TO USE:
 * 1. Compile and run this Java file.
 * 2. Create a file named "servers.txt" in the SAME directory where you run the program.
 * 3. Add the base URLs of the servers you want to search to this file, one URL per line.
 *
 * SEARCH LOGIC:
 * - If you enter text WITHOUT a dot (e.g., "car"), the program calculates its
 * SHA-256 hash and searches for a resource at: {server_url}/data/{hash}/index.html
 *
 * - If you enter text WITH a dot (e.g., "car.jpg"), the program searches for a
 * file directly at: {server_url}/files/{your_input}
 *
 * Results found will be displayed in the table. Clicking a row will open the URL in your browser.
 */
public class Seacher extends JFrame {

    private final JTextField searchField;
    private final JButton searchButton;
    private final JTable resultsTable;
    private final DefaultTableModel tableModel;
    private final JLabel statusLabel;

    public static void main(String[] args) {
        // Run the GUI creation on the Event Dispatch Thread for thread safety
        SwingUtilities.invokeLater(() -> {
            Seacher finder = new Seacher();
            finder.setVisible(true);
        });
    }

    public Seacher() {
        super("Decenhash Seacher");

        // --- Window Setup ---
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null); // Center the window
        setLayout(new BorderLayout(10, 10));

        // --- Top Panel for Input ---
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        topPanel.setBackground(new Color(240, 240, 240));

        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 18));
        searchField.setToolTipText("Enter a search term or a full filename");

        searchButton = new JButton("Search");
        searchButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        searchButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        searchButton.setToolTipText("Click to begin the search across specified servers");

        topPanel.add(new JLabel("Enter Search Term or Filename:"), BorderLayout.NORTH);
        topPanel.add(searchField, BorderLayout.CENTER);
        topPanel.add(searchButton, BorderLayout.EAST);

        // --- Center Panel for Results Table ---
        String[] columnNames = {"Status", "Resource URL"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make table cells non-editable
                return false;
            }
        };
        resultsTable = new JTable(tableModel);
        resultsTable.setFont(new Font("SansSerif", Font.PLAIN, 14));
        resultsTable.setRowHeight(25);
        resultsTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        // Set column widths
        resultsTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        resultsTable.getColumnModel().getColumn(0).setMaxWidth(120);
        resultsTable.getColumnModel().getColumn(1).setPreferredWidth(600);


        JScrollPane scrollPane = new JScrollPane(resultsTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Search Results"));

        // --- Bottom Panel for Status ---
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusLabel = new JLabel("Ready. Enter a term and click Search.");
        statusLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        bottomPanel.add(statusLabel);

        // --- Add Components to Frame ---
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // --- Action Listeners ---
        // Trigger search on button click or pressing Enter in the text field
        searchButton.addActionListener(e -> startSearch());
        searchField.addActionListener(e -> startSearch());

        // Add listener to the table to open URLs on click
        resultsTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = resultsTable.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    // Check for double-click to open
                    if (e.getClickCount() == 2) {
                        String url = (String) tableModel.getValueAt(row, 1);
                        String status = (String) tableModel.getValueAt(row, 0);
                        if ("Found".equals(status)) {
                            openUrlInBrowser(url);
                        }
                    }
                }
            }
        });
    }

    /**
     * Initiates the search process by creating and executing a background worker thread.
     */
    private void startSearch() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search term.", "Input Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Clear previous results and disable UI during search
        tableModel.setRowCount(0);
        searchButton.setEnabled(false);
        searchField.setEnabled(false);
        statusLabel.setText("Searching for: " + query);

        // Run the search in a background thread to keep the GUI responsive
        SearchWorker worker = new SearchWorker(query);
        worker.execute();
    }

    /**
     * Converts a string to its SHA-256 hash representation.
     * @param input The string to hash.
     * @return The SHA-256 hash as a lowercase hexadecimal string.
     */
    private static String toSha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            // This should never happen with SHA-256, a standard algorithm
            throw new RuntimeException("SHA-256 algorithm not found", e);
        }
    }

    /**
     * Attempts to open the given URL in the user's default web browser.
     * @param urlString The URL to open.
     */
    private void openUrlInBrowser(String urlString) {
        try {
            Desktop.getDesktop().browse(new URI(urlString));
        } catch (Exception ex) {
            statusLabel.setText("Error opening URL: " + ex.getMessage());
            JOptionPane.showMessageDialog(this,
                "Could not open the URL in the browser.\nURL: " + urlString + "\nError: " + ex.getMessage(),
                "Browser Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * SwingWorker class to perform network operations in the background,
     * preventing the GUI from freezing.
     */
    class SearchWorker extends SwingWorker<Void, String[]> {
        private final String query;

        SearchWorker(String query) {
            this.query = query;
        }

        @Override
        protected Void doInBackground() throws Exception {
            File serversFile = new File("servers.txt");
            if (!serversFile.exists()) {
                // Publish a special message if the file is not found
                publish(new String[]{"Error", "File 'servers.txt' not found in the application directory."});
                return null;
            }

            List<String> servers = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(serversFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (!line.isEmpty() && (line.startsWith("http://") || line.startsWith("https://"))) {
                        servers.add(line);
                    }
                }
            } catch (IOException e) {
                publish(new String[]{"Error", "Failed to read 'servers.txt': " + e.getMessage()});
                return null;
            }

            if (servers.isEmpty()) {
                publish(new String[]{"Info", "No valid server URLs found in 'servers.txt'."});
                return null;
            }

            boolean isFileInput = query.contains(".");
            String searchTerm = isFileInput ? query : toSha256(query);

            for (String server : servers) {
                String urlToCheck;
                if (isFileInput) {
                    urlToCheck = server + "/files/" + searchTerm;
                } else {
                    urlToCheck = server + "/data/" + searchTerm + "/index.html";
                }

                publish(new String[]{"Checking", urlToCheck}); // Update UI with current check
                boolean exists = checkUrlExists(urlToCheck);
                if (exists) {
                    publish(new String[]{"Found", urlToCheck}); // Publish found results
                }
            }
            return null;
        }

        /**
         * Checks if a resource exists at the given URL by making an HTTP HEAD request.
         */
        private boolean checkUrlExists(String urlString) {
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                // Use HEAD request for efficiency, as we only need the status code, not the content.
                connection.setRequestMethod("HEAD");
                connection.setConnectTimeout(5000); // 5 seconds
                connection.setReadTimeout(5000); // 5 seconds
                int responseCode = connection.getResponseCode();
                // A response code of 200 OK means the resource exists.
                return (responseCode == HttpURLConnection.HTTP_OK);
            } catch (IOException e) {
                // Any exception (e.g., connection timed out, 404 Not Found) means it's not accessible.
                return false;
            }
        }

        @Override
        protected void process(List<String[]> chunks) {
            // This method is called on the Event Dispatch Thread to safely update the GUI
            for (String[] result : chunks) {
                String status = result[0];
                String url = result[1];
                
                // If status is "Found" or an error/info message, add it as a new row.
                // Otherwise, update the last "Checking..." row.
                if ("Found".equals(status) || "Error".equals(status) || "Info".equals(status)) {
                    // Update the "Checking..." row to "Found" if it's the same URL
                    boolean updated = false;
                    if (tableModel.getRowCount() > 0) {
                        int lastRow = tableModel.getRowCount() - 1;
                        if (url.equals(tableModel.getValueAt(lastRow, 1))) {
                           tableModel.setValueAt(status, lastRow, 0);
                           updated = true;
                        }
                    }
                    if(!updated) {
                         tableModel.addRow(result);
                    }
                } else { // "Checking"
                    tableModel.addRow(result);
                    resultsTable.scrollRectToVisible(resultsTable.getCellRect(tableModel.getRowCount()-1, 0, true));
                }
            }
        }

        @Override
        protected void done() {
            // This method is called when doInBackground completes
            try {
                get(); // To catch any exceptions from doInBackground
                statusLabel.setText("Search complete. Double-click a 'Found' result to open.");
            } catch (InterruptedException | ExecutionException e) {
                statusLabel.setText("An error occurred during the search: " + e.getCause().getMessage());
            } finally {
                // Re-enable UI components
                searchButton.setEnabled(true);
                searchField.setEnabled(true);
            }
        }
    }
}
